# -*- coding: utf-8 -*-
"""pyRevit har yuklanganda (Revit ochilganda va Reload'da) shu fayl ishlaydi.

Avtosaqlash dvigatelini ishga tushiradi; yoqilgan-o'chirilganini u sozlamadan
o'zi o'qiydi. Bu yerdagi xato plaginning yuklanishiga xalaqit bermasligi kerak.
"""
try:
    from archstore import autosave_engine
    autosave_engine.ensure_running(restart=True)
except Exception:
    pass
