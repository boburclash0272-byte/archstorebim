# -*- coding: utf-8 -*-
"""ArchStore BIM - Sozlamalar.

Hamma asboblarga taalluqli sozlamalar bitta joyda: mavzu (ranglar), til va
yangilanish. Tanlov darhol saqlanadi."""

__title__ = 'Sozlamalar'
__author__ = 'ArchStore BIM'
__context__ = 'zero-doc'        # loyiha ochiq bo'lmasa ham ishlaydi

import clr

clr.AddReference('WindowsBase')
clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')

from archstore import catalog, theme, updater
from archstore.i18n import LANGS, T, get_lang, set_lang
from archstore.ui import ToolWindow, apply_theme, run_update_flow, safe

LANGUAGE_NAMES = {'uz': u"O'zbekcha", 'ru': u'Русский', 'en': u'English'}


def save_setting(key, value):
    settings = catalog.load_settings()
    settings[key] = value
    catalog.save_settings(settings)


class SettingsWindow(ToolWindow):
    def __init__(self):
        ToolWindow.__init__(self)
        self.want_update = False
        self.theme_buttons = {'auto': self.auto_rb, 'light': self.light_rb, 'dark': self.dark_rb}
        self.lang_buttons = {'uz': self.uz_rb, 'ru': self.ru_rb, 'en': self.en_rb}

        mode = catalog.load_settings().get('theme')
        mode = mode if mode in theme.MODES else 'auto'
        for key, button in self.theme_buttons.items():
            button.IsChecked = key == mode
            button.Click += self.on_theme
        for key, button in self.lang_buttons.items():
            button.Content = LANGUAGE_NAMES[key]
            button.IsChecked = key == get_lang()
            button.Click += self.on_lang
        self.update_btn.Click += self.on_update
        self.close_btn.Click += self.on_close
        self.apply_texts()

    def apply_texts(self):
        self.title_tb.Text = T('st_title')
        self.theme_label.Text = T('theme_label')
        for key, button in self.theme_buttons.items():
            button.Content = T('theme_' + key)
        self.theme_note.Text = T('st_theme_note')
        self.lang_label.Text = T('st_lang')
        self.note_tb.Text = T('st_note')
        self.update_label.Text = T('st_update')
        self.version_tb.Text = T('up_version') % updater.read_local()['version']
        self.update_btn.Content = T('st_check')
        self.close_btn.Content = T('as_close')

    @staticmethod
    def chosen(buttons):
        for key, button in buttons.items():
            if button.IsChecked:
                return key
        return None

    @safe
    def on_theme(self, sender, args):
        mode = self.chosen(self.theme_buttons)
        if mode in theme.MODES:
            save_setting('theme', mode)
            self.theme_name = apply_theme(self)     # shu oynaning o'zida darhol ko'rinadi

    @safe
    def on_lang(self, sender, args):
        code = self.chosen(self.lang_buttons)
        if code in LANGS and code != get_lang():
            set_lang(code)
            save_setting('lang', code)
            self.apply_texts()

    @safe
    def on_update(self, sender, args):
        self.want_update = True                     # tekshiruv oyna yopilgandan keyin boshlanadi
        self.Close()

    @safe
    def on_close(self, sender, args):
        self.Close()


def main():
    set_lang(catalog.load_settings().get('lang'))
    window = SettingsWindow()
    window.show_dialog()
    if window.want_update:
        run_update_flow()


main()
