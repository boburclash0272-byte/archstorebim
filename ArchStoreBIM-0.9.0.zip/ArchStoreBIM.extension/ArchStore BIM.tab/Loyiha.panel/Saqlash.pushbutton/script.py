# -*- coding: utf-8 -*-
"""ArchStore BIM - Saqlash.

Hali saqlanmagan loyiha uchun: papka tanlanadi, fayl nomi yoziladi - tanlangan
papka ichida loyiha papkalari (010_... 060_...) yaratiladi va Revit fayli ish
papkasiga saqlanadi. Avval saqlangan fayl o'z joyiga saqlanadi."""

__title__ = 'Saqlash'
__author__ = 'ArchStore BIM'

import os

import clr

clr.AddReference('WindowsBase')
clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')

from pyrevit import DB, forms, revit

from archstore import catalog, projfolders
from archstore.i18n import T, set_lang
from archstore.ui import APP, ToolWindow, safe


class SaveWindow(ToolWindow):
    def __init__(self):
        ToolWindow.__init__(self)
        self.accepted = False
        self.root = u''
        self.name = u''
        self.overwrite = False
        self._ready = False

        self.title_tb.Text = T('sv_title')
        self.sub_tb.Text = T('sv_sub') % projfolders.WORK
        self.folder_label.Text = T('sv_folder')
        self.pick_btn.Content = T('sv_pick')
        self.name_label.Text = T('sv_name')
        self.tree_label.Text = T('sv_tree')
        self.note_tb.Text = T('sv_note')
        self.ok_btn.Content = T('sv_save')
        self.cancel_btn.Content = T('btn_cancel')

        self.pick_btn.Click += self.on_pick
        self.folder_tb.TextChanged += self.on_change
        self.name_tb.TextChanged += self.on_change
        self.ok_btn.Click += self.on_ok
        self.cancel_btn.Click += self.on_cancel
        self._ready = True
        self.update()

    def state(self):
        """(papka, fayl nomi, ogohlantirish matni, saqlash mumkinmi)"""
        root = projfolders.clean_root(self.folder_tb.Text)
        name = projfolders.clean_file_name(self.name_tb.Text)
        if not root:
            return root, name or u'', T('sv_need_folder'), False
        if not os.path.isdir(root):
            return root, name or u'', T('sv_no_folder'), False
        if name is None:
            return root, u'', T('sv_bad_name'), False
        if not name:
            return root, u'', T('sv_need_name'), False
        if os.path.exists(projfolders.target_path(root, name)):
            return root, name, T('sv_file_exists'), True
        return root, name, u'', True

    def update(self):
        root, name, warning, ready = self.state()
        self.warn_tb.Text = warning
        self.tree_lb.ItemsSource = projfolders.lines(root, name, T('sv_exists'), T('sv_new'))
        self.ok_btn.IsEnabled = ready

    @safe
    def on_change(self, sender, args):
        if self._ready:
            self.update()

    @safe
    def on_pick(self, sender, args):
        folder = forms.pick_folder(title=T('sv_pick_title'))
        if folder:
            self.folder_tb.Text = folder
            self.update()

    @safe
    def on_ok(self, sender, args):
        root, name, warning, ready = self.state()
        if not ready:
            return
        overwrite = False
        if os.path.exists(projfolders.target_path(root, name)):
            agreed = forms.alert(T('sv_overwrite') % (name + projfolders.EXTENSION), title=APP,
                                 ok=False, yes=True, no=True)
            if not agreed:
                return
            overwrite = True
        self.root, self.name, self.overwrite = root, name, overwrite
        self.accepted = True
        self.Close()

    @safe
    def on_cancel(self, sender, args):
        self.Close()


def save_in_place(doc):
    """Avval saqlangan fayl: oddiy saqlash (Ctrl+S kabi)."""
    try:
        doc.Save()
    except Exception as err:
        forms.alert(T('sv_failed'), sub_msg=u'%s' % err, title=APP)
        return
    forms.alert(T('sv_saved'), sub_msg=u'%s\n\n%s' % (doc.PathName, T('sv_saved_note')), title=APP,
                warn_icon=False)


def save_new(doc, root, name, overwrite):
    """Papkalarni yaratadi va faylni ish papkasiga saqlaydi."""
    try:
        made = projfolders.create(root)
    except Exception as err:
        forms.alert(T('sv_folders_failed'), sub_msg=u'%s' % err, title=APP)
        return
    path = projfolders.target_path(root, name)
    try:
        options = DB.SaveAsOptions()
        options.OverwriteExistingFile = overwrite
        if doc.IsWorkshared:
            sharing = DB.WorksharingSaveAsOptions()
            sharing.SaveAsCentral = True
            options.SetWorksharingOptions(sharing)
        doc.SaveAs(path, options)
    except Exception as err:
        forms.alert(T('sv_failed'), sub_msg=u'%s' % err, title=APP)
        return
    forms.alert(T('sv_done'), sub_msg=u'%s\n\n%s' % (path, T('sv_created') % len(made)), title=APP,
                warn_icon=False)


def main():
    doc = revit.doc
    set_lang(catalog.load_settings().get('lang'))

    if doc.PathName:
        save_in_place(doc)
        return
    if doc.IsFamilyDocument:
        forms.alert(T('sv_family'), title=APP)
        return
    window = SaveWindow()
    window.show_dialog()
    if window.accepted:
        save_new(doc, window.root, window.name, window.overwrite)


main()
