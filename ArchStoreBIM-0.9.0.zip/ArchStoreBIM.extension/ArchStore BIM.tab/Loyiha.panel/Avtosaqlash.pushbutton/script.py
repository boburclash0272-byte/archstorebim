# -*- coding: utf-8 -*-
"""ArchStore BIM - Avtosaqlash.

Ochiq fayllarni tanlangan oraliqda (15 daqiqa / 30 daqiqa / 1 soat; sinov uchun 30 soniya)
o'zi saqlaydi.
Bu oyna faqat sozlaydi; saqlashni fonda ishlaydigan dvigatel bajaradi
(lib/archstore/autosave_engine.py)."""

__title__ = 'Avto-\nsaqlash'
__author__ = 'ArchStore BIM'
__context__ = 'zero-doc'            # loyiha ochiq bo'lmasa ham sozlash mumkin
# Dvigatel shu oynadan ishga tushirilgan bo'lsa, oyna yopilgandan keyin ham yashashi kerak
__persistentengine__ = True

from pyrevit import forms

from archstore import autosave, autosave_engine, catalog
from archstore.i18n import T, set_lang
from archstore.ui import APP, ToolWindow, report, safe, vis

LABELS = {autosave.TEST: 'as_test', 15: 'as_15', 30: 'as_30', 60: 'as_60'}


class AutosaveWindow(ToolWindow):
    def __init__(self):
        ToolWindow.__init__(self)
        self._ready = False
        self.buttons = {autosave.TEST: self.test_rb, 15: self.m15_rb, 30: self.m30_rb, 60: self.m60_rb}
        self.title_tb.Text = T('as_title')
        self.interval_label.Text = T('as_interval')
        self.last_label.Text = T('as_last_label')
        self.note_tb.Text = T('as_note')
        self.close_btn.Content = T('as_close')
        for minutes, button in self.buttons.items():
            button.Content = T(LABELS[minutes])
            button.Click += self.on_interval
        self.toggle_btn.Click += self.on_toggle
        self.close_btn.Click += self.on_close
        self.show_state()
        self._ready = True

    def config(self):
        return autosave.read(catalog.load_settings())

    def show_state(self):
        """Oynani sozlamadagi holatga keltiradi."""
        config = self.config()
        on = config['enabled']
        self.state_tb.Text = T('as_on') if on else T('as_off')
        self.toggle_btn.Content = T('as_turn_off') if on else T('as_turn_on')
        ready, self._ready = self._ready, False
        for minutes, button in self.buttons.items():
            button.IsChecked = minutes == config['minutes']
        self._ready = ready
        if on:
            left = autosave_engine.remaining_minutes()
            if left is None:
                self.next_tb.Text = u''
            else:
                self.next_tb.Text = (T('as_next') % left) if left else T('as_next_soon')
        else:
            self.next_tb.Text = T('as_off_hint')
        last = autosave.last(catalog.load_settings())
        if last is None:
            self.last_tb.Text = T('as_never')
            self.warn_tb.Visibility = vis(False)
            return
        self.last_tb.Text = T('as_last') % (last.get('at'), last.get('saved') or 0)
        problems = []
        if last.get('unsaved'):
            problems.append(T('as_unsaved') % u', '.join(last['unsaved']))
        if last.get('error'):
            problems.append(T('as_error') % last['error'])
        self.warn_tb.Text = u'\n'.join(problems)
        self.warn_tb.Visibility = vis(bool(problems))

    def change(self, enabled=None, minutes=None):
        settings = catalog.load_settings()
        catalog.save_settings(autosave.write(settings, enabled=enabled, minutes=minutes))
        autosave_engine.restart_countdown()         # vaqt hisobi shu paytdan boshlanadi
        self.show_state()

    @safe
    def on_toggle(self, sender, args):
        self.change(enabled=not self.config()['enabled'])

    @safe
    def on_interval(self, sender, args):
        if not self._ready:
            return
        for minutes, button in self.buttons.items():
            if button.IsChecked:
                self.change(minutes=minutes)
                return

    @safe
    def on_close(self, sender, args):
        self.Close()


def main():
    set_lang(catalog.load_settings().get('lang'))
    try:
        autosave_engine.ensure_running()            # Revit ochilganda ishga tushmagan bo'lsa, shu yerda tushadi
    except Exception as err:
        forms.alert(T('as_engine_failed'), sub_msg=u'%s' % err, title=APP)
        return
    AutosaveWindow().show_dialog()


try:
    main()
except Exception:
    import traceback
    report(traceback.format_exc())
