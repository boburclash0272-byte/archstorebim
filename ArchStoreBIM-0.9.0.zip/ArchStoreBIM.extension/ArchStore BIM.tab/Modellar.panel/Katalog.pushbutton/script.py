# -*- coding: utf-8 -*-
"""ArchStore BIM - model kutubxonasi.

Kutubxona papkasidagi modellar va materiallarni ko'rsatadi, loyihaga yuklaydi
va joylashtiradi. Oyna Revit yonida ochiq turadi (modal emas)."""

__title__ = 'Katalog'
__author__ = 'ArchStore BIM'
# Oyna skript tugagandan keyin ham yashashi uchun pyRevit dvigateli o'chirilmaydi
__persistentengine__ = True

import os
import time
import traceback

import clr

# WPF turlari (Visibility, BitmapImage...) shu kutubxonalarda - avval ulab olamiz
clr.AddReference('WindowsBase')
clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')

from System import Action
from System.Collections.Generic import List
from System.IO import File, MemoryStream
from System.Windows import (FontWeights, PresentationSource, SystemParameters, Thickness,
                            Visibility, WindowStartupLocation, WindowState)
from System.Windows.Controls import ItemsControl
from System.Windows.Media import Color, ColorConverter, SolidColorBrush
from System.Windows.Media.Imaging import BitmapCacheOption, BitmapImage
from System.Windows.Threading import DispatcherPriority
from System.Threading import ThreadPool, WaitCallback

from pyrevit import DB, HOST_APP, UI, forms, revit, script
from Autodesk.Revit.Exceptions import OperationCanceledException
from Autodesk.Revit.UI.Selection import ObjectType

from archstore import access, catalog, styles, theme, updater
from archstore.i18n import LANGS, T, get_lang, set_lang
from archstore.ui import run_update_flow

APP = u'ArchStore BIM'
HOST_YEAR = int(HOST_APP.version)
MAX_CARDS = 300                       # bir vaqtda ko'rsatiladigan kartochkalar
WINDOW_VAR = 'ARCHSTOREBIM_WINDOW'    # ochiq oynani eslab qolish uchun
WIDE_MIN = (940.0, 540.0)             # to'liq oynaning eng kichik o'lchami
DOCK_MIN = (300.0, 400.0)             # yon panelning eng kichik o'lchami
DOCK_WIDTH = 324.0                    # yon panel eni: ikki ustun kichik kartochka
DOT = u'  ·  '


# --- yordamchilar ------------------------------------------------------------

def _vis(flag):
    return Visibility.Visible if flag else Visibility.Collapsed


def _bitmap(path, width):
    if not path:
        return None
    try:
        bmp = BitmapImage()
        bmp.BeginInit()
        bmp.CacheOption = BitmapCacheOption.OnLoad
        bmp.DecodePixelWidth = width
        bmp.StreamSource = MemoryStream(File.ReadAllBytes(path))
        bmp.EndInit()
        bmp.Freeze()
        return bmp
    except Exception:
        return None


def _brush(rgb):
    r, g, b = rgb or (201, 197, 186)
    brush = SolidColorBrush(Color.FromRgb(r, g, b))
    brush.Freeze()
    return brush


def _hex_brush(value):
    brush = SolidColorBrush(ColorConverter.ConvertFromString(value))
    brush.Freeze()
    return brush


def revit_is_dark():
    """Revit hozir qorong'i mavzudami (Revit 2024+; eski versiyalarda doim yorug')."""
    try:
        return UI.UIThemeManager.CurrentTheme == UI.UITheme.Dark
    except Exception:
        return False


def _size_text(size):
    if size >= 1024 * 1024:
        return u'%.1f MB' % (size / 1048576.0)
    return u'%d KB' % max(1, size // 1024)


def report(text):
    """Kutilmagan xatoni ko'rsatadi (oyna modal emas - xato Revit'ni yiqitmasligi kerak)."""
    try:
        forms.alert(T('err_unexpected'), sub_msg=text, title=APP)
    except Exception:
        pass


def safe(handler):
    """Oyna hodisalaridagi xatolarni ushlab, matnini ko'rsatadi."""
    def wrapper(self, *args):
        try:
            return handler(self, *args)
        except Exception:
            report(traceback.format_exc())
    return wrapper


# --- oynadagi qatorlar (XAML shu maydonlarga bog'lanadi) ---------------------

class NavRow(object):
    def __init__(self, kind, value=None, text=u'', count=u''):
        self.kind = kind                # all | fav | recent | materials | cat | brand | set | head
        self.value = value
        head = kind == 'head'
        self.enabled = not head
        self.header = text if head else u''
        self.text = u'' if head else text
        self.count = u'%s' % count
        self.combo = text if self.count == u'' else u'%s  (%s)' % (text, self.count)
        self.head_vis = _vis(head)
        self.row_vis = _vis(not head)


class InfoRow(object):
    def __init__(self, label, value):
        self.label = label
        self.value = value


class TypeRow(object):
    def __init__(self, data):
        self.name = data.get('name', u'')
        self.params = data.get('params') or []


class Card(object):
    """Bitta model kartochkasi."""
    is_material = False

    def __init__(self, item, is_fav, bitmaps):
        self.item = item
        self.key = item.key
        self._bitmaps = bitmaps
        self.title = item.title
        self.too_new = bool(item.year and item.year > HOST_YEAR)
        self.no_thumb = _vis(not item.thumb_path)
        self.no_thumb_text = T('no_image')
        self.pro = _vis(item.is_pro)
        self.fav = _vis(is_fav)
        self.swatch = None
        self.swatch_vis = Visibility.Collapsed
        place = item.category or T('unsorted')
        self.sub = (item.brand + DOT + place) if item.brand else place
        self.warn = _vis(self.too_new)
        self.warn_text = (T('needs_revit') % item.year) if self.too_new else u''

    @property
    def thumb(self):
        # rasm faqat kartochka ekranga chiqqanda o'qiladi
        path = self.item.thumb_path
        if path not in self._bitmaps:
            self._bitmaps[path] = _bitmap(path, 256)
        return self._bitmaps[path]


class MaterialCard(object):
    """Bitta material kartochkasi (rasm o'rnida rang)."""
    is_material = True

    def __init__(self, material):
        self.material = material
        self.key = u'm:%s|%s' % (material.path.lower(), material.name)
        self.title = material.name
        self.sub = material.material_class or material.collection
        self.thumb = None
        self.no_thumb = Visibility.Collapsed
        self.no_thumb_text = u''
        self.pro = Visibility.Collapsed
        self.fav = Visibility.Collapsed
        self.warn = Visibility.Collapsed
        self.warn_text = u''
        self.swatch = _brush(material.color)
        self.swatch_vis = Visibility.Visible


# --- Revit amallari ----------------------------------------------------------
# Bularning hammasi faqat Revit navbati kelganda (Dispatcher ichida) chaqiriladi.

class Dispatcher(UI.IExternalEventHandler):
    """Oyna modal bo'lmagani uchun Revit API'ga to'g'ridan-to'g'ri murojaat qilib
    bo'lmaydi. Ishlar navbatga qo'yiladi va Revit bo'shaganda shu yerda bajariladi."""

    def __init__(self):
        self.jobs = []

    def Execute(self, uiapp):
        jobs, self.jobs = self.jobs, []
        for job in jobs:
            try:
                job(uiapp)
            except Exception:
                report(traceback.format_exc())

    def GetName(self):
        return 'ArchStore BIM'


class Tx(object):
    """with Tx(doc, nom): ...  - xato bo'lsa o'zgarishlar bekor qilinadi."""

    def __init__(self, doc, name):
        self.tx = DB.Transaction(doc, name)

    def __enter__(self):
        self.tx.Start()
        return self

    def __exit__(self, kind, value, trace):
        if kind is None:
            self.tx.Commit()
        elif self.tx.HasStarted() and not self.tx.HasEnded():
            self.tx.RollBack()
        return False


class LoadOptions(DB.IFamilyLoadOptions):
    """Ichki (nested) family'lar to'qnashsa: kutubxonadagi variant olinadi,
    loyihadagi parametr qiymatlari saqlanadi."""

    def OnFamilyFound(self, familyInUse, overwriteParameterValues):
        overwriteParameterValues.Value = False
        return True

    def OnSharedFamilyFound(self, sharedFamily, familyInUse, source,
                            overwriteParameterValues):
        source.Value = DB.FamilySource.Family
        overwriteParameterValues.Value = False
        return True


class KeepProjectTypes(DB.IDuplicateTypeNamesHandler):
    """Material ko'chirishda bir xil nomli tiplar uchrasa - loyihadagisi qoladi."""

    def OnDuplicateTypeNamesFound(self, args):
        return DB.DuplicateTypeAction.UseDestinationTypes


def _named(doc, cls):
    return dict((revit.query.get_name(e), e)
                for e in DB.FilteredElementCollector(doc).OfClass(cls))


def load_items(doc, items):
    """Modellarni loyihaga yuklaydi.

    Qaytaradi: (families, loaded, existed, failed)
      families - {item.key: Family}
      failed   - [(nom, sabab), ...]
    Loyihada shu nomli family bo'lsa, u o'zgartirilmaydi - o'shani ishlatamiz.
    """
    families, loaded, existed, failed = {}, [], [], []
    in_project = _named(doc, DB.Family)
    todo = []
    for item in items:
        if not access.can_use(item):
            failed.append((item.title, T('err_pro')))
        elif item.year and item.year > HOST_YEAR:
            failed.append((item.title, T('err_newer') % (item.year, HOST_YEAR)))
        elif not os.path.isfile(item.path):
            failed.append((item.title, T('err_missing')))
        elif item.family_name in in_project:
            families[item.key] = in_project[item.family_name]
            existed.append(item.title)
        else:
            todo.append(item)
    if todo:
        with Tx(doc, APP + u': model yuklash'):
            for item in todo:
                ref = clr.Reference[DB.Family]()
                try:
                    ok = doc.LoadFamily(item.path, LoadOptions(), ref)
                except Exception as err:
                    failed.append((item.title, u'%s' % err))
                    continue
                if ok and ref.Value:
                    families[item.key] = ref.Value
                    loaded.append(item.title)
                else:
                    failed.append((item.title, T('err_refused')))
    return families, loaded, existed, failed


def prepare_symbol(doc, item, family, type_name):
    """Tanlangan tipni (yoki birinchisini) faol holatda qaytaradi; yo'q bo'lsa None."""
    symbols = [doc.GetElement(i) for i in family.GetFamilySymbolIds()]
    symbol = None
    if type_name:
        for s in symbols:
            if revit.query.get_name(s) == type_name:
                symbol = s
                break
        if symbol is None and item.has_type_catalog:
            # tip faqat type catalog (.txt) ichida - uni alohida yuklaymiz
            ref = clr.Reference[DB.FamilySymbol]()
            with Tx(doc, APP + u': tip yuklash'):
                doc.LoadFamilySymbol(item.path, type_name, LoadOptions(), ref)
            symbol = ref.Value
    if symbol is None and symbols:
        symbol = symbols[0]
    if symbol is not None and not symbol.IsActive:
        with Tx(doc, APP + u': tipni faollashtirish'):
            symbol.Activate()
    return symbol


def _open_source(app, path):
    """(.rvt hujjati, yopish kerakmi) - fayl allaqachon ochiq bo'lsa, o'shani oladi."""
    wanted = os.path.normcase(os.path.abspath(path))
    for doc in app.Documents:
        if doc.PathName and os.path.normcase(os.path.abspath(doc.PathName)) == wanted:
            return doc, False
    return app.OpenDocumentFile(path), True


def read_materials(app, path):
    """.rvt fayl ichidagi materiallar ro'yxati (katalog keshiga yoziladigan ko'rinishda)."""
    src, close = _open_source(app, path)
    try:
        records = []
        for mat in DB.FilteredElementCollector(src).OfClass(DB.Material):
            color = mat.Color
            rgb = None
            if color is not None and color.IsValid:
                rgb = [int(color.Red), int(color.Green), int(color.Blue)]
            records.append({'name': revit.query.get_name(mat),
                            'class': mat.MaterialClass or u'', 'color': rgb})
        return records
    finally:
        if close:
            src.Close(False)


def import_materials(app, doc, materials):
    """Materiallarni kutubxonadagi .rvt fayldan loyihaga ko'chiradi.

    Qaytaradi: (loaded, existed, failed) - failed: [(nom, sabab), ...]
    """
    loaded, existed, failed = [], [], []
    in_project = _named(doc, DB.Material)
    by_file = {}
    for mat in materials:
        if mat.name in in_project:
            existed.append(mat.name)
        else:
            by_file.setdefault(mat.path, []).append(mat)
    for path, wanted in by_file.items():
        try:
            src, close = _open_source(app, path)
        except Exception as err:
            failed.extend((m.name, u'%s: %s' % (T('err_material_file'), err)) for m in wanted)
            continue
        try:
            in_source = _named(src, DB.Material)
            ids = List[DB.ElementId]()
            names = []
            for mat in wanted:
                if mat.name in in_source:
                    ids.Add(in_source[mat.name].Id)
                    names.append(mat.name)
                else:
                    failed.append((mat.name, T('err_material_missing')))
            if names:
                options = DB.CopyPasteOptions()
                options.SetDuplicateTypeNamesHandler(KeepProjectTypes())
                try:
                    with Tx(doc, APP + u': material yuklash'):
                        DB.ElementTransformUtils.CopyElements(
                            src, ids, doc, DB.Transform.Identity, options)
                    loaded.extend(names)
                except Exception as err:
                    failed.extend((n, u'%s' % err) for n in names)
        finally:
            if close:
                src.Close(False)
    return loaded, existed, failed


def paint_faces(uidoc, material):
    """Foydalanuvchi tanlagan sirtlarga material qo'llaydi (Esc - tugatish).
    Qo'llangan sirtlar sonini qaytaradi."""
    doc = uidoc.Document
    done = 0
    while True:
        try:
            ref = uidoc.Selection.PickObject(ObjectType.Face, T('pick_face'))
        except OperationCanceledException:
            return done
        try:
            element = doc.GetElement(ref)
            face = element.GetGeometryObjectFromReference(ref)
            with Tx(doc, APP + u': material qo\'llash'):
                doc.Paint(element.Id, face, material.Id)
            done += 1
        except Exception as err:
            forms.alert(T('err_paint'), sub_msg=u'%s' % err, title=APP)


def summary(loaded, existed, failed):
    parts = []
    if loaded:
        parts.append(T('done_loaded') % len(loaded))
    if existed:
        parts.append(T('done_existed') % len(existed))
    if failed:
        parts.append(T('done_failed') % len(failed))
    return DOT.join(parts)


def prepare(lib):
    """Rasm, versiya va tiplarni tayyorlaydi; yangi fayllar bo'lsa progress ko'rsatadi."""
    state = {'bar': None}

    def on_progress(done, total):
        if state['bar'] is None:
            state['bar'] = forms.ProgressBar(title=T('progress'))
            state['bar'].__enter__()
        state['bar'].update_progress(done, total)

    try:
        lib.enrich(on_progress)
    finally:
        if state['bar'] is not None:
            state['bar'].__exit__(None, None, None)


# --- oyna --------------------------------------------------------------------

class CatalogWindow(forms.WPFWindow):
    def __init__(self, root, dispatcher, event):
        # handle_esc=False: Esc Revit'dagi buyruqni bekor qilish uchun kerak, oynani yopmasin
        forms.WPFWindow.__init__(self, styles.compose(script.get_bundle_file('ui.xaml')),
                                 handle_esc=False)
        self.dispatcher = dispatcher
        self.event = event
        self.lib = None
        self._ready = False
        self._nav = ('all', None)
        self._bitmaps = {}
        self._editing = []          # tahrirlanayotgan modellar
        self._reading = False       # materiallar o'qilmoqda
        self._tried = set()         # shu seansda o'qib ko'rilgan material fayllari
        self._total = 0
        self._docked = False        # yon panel rejimi
        self._theme_mode = 'auto'   # auto | light | dark
        self._theme = None          # hozir qo'llangan mavzu: light | dark
        self._update_version = None # serverda topilgan yangi versiya
        self._wide_box = None       # to'liq oynaning joyi (yon paneldan qaytish uchun)
        self._area = None           # chizma maydoni [o'ng, tepa, past], ekran piksellarida
        try:
            area = HOST_APP.uiapp.DrawingAreaExtents
            self._area = [area.Right, area.Top, area.Bottom]
        except Exception:
            pass

        self.search_tb.TextChanged += self.on_search
        self.nav_lb.SelectionChanged += self.on_nav
        self.nav_cb.SelectionChanged += self.on_nav_combo
        self.dock_btn.Click += self.on_dock
        self.update_btn.Click += self.on_update
        self.Activated += self.on_activated
        self.cards_lb.SelectionChanged += self.on_select
        self.cards_lb.MouseDoubleClick += self.on_double_click
        self.types_lb.SelectionChanged += self.on_type
        self.folder_btn.Click += self.on_folder
        self.load_btn.Click += self.on_load
        self.place_btn.Click += self.on_place
        self.fav_btn.Click += self.on_favorite
        self.set_btn.Click += self.on_set
        self.edit_btn.Click += self.on_edit
        self.save_btn.Click += self.on_save
        self.cancel_btn.Click += self.on_cancel
        for button in (self.lang_uz, self.lang_ru, self.lang_en):
            button.Click += self.on_lang
        self.Closed += self.on_closed

        self.enable_keyboard()
        self.restore_window()
        self.apply_theme(catalog.load_settings().get('theme'))
        self.apply_texts()
        self.open_library(root)
        self.check_updates()

    # --- umumiy ---

    def run(self, job):
        """Ishni Revit navbatiga qo'yadi."""
        self.dispatcher.jobs.append(job)
        self.event.Raise()
        self.say(T('queued'))

    def say(self, message):
        self.status_tb.Text = message
        self.status2_tb.Text = message      # yon panel rejimidagi holat qatori

    def apply_texts(self):
        """Tilga bog'liq o'zgarmas matnlar."""
        self.search_hint.Text = T('search_hint')
        self.folder_label.Text = T('folder_label')
        self.folder_btn.Content = T('folder_btn')
        self.detail_empty.Text = T('detail_empty')
        self.types_head.Text = T('head_types')
        self.dims_head.Text = T('head_dims')
        self.edit_btn.Content = T('btn_edit')
        self.e_title_label.Text = T('edit_title')
        self.e_brand_label.Text = T('edit_brand')
        self.e_desc_label.Text = T('edit_description')
        self.e_pro.Content = T('edit_pro')
        self.save_btn.Content = T('btn_save')
        self.cancel_btn.Content = T('btn_cancel')
        self.dock_btn.Content = T('btn_expand') if self._docked else T('btn_dock')
        self.dock_btn.ToolTip = T('tip_expand') if self._docked else T('tip_dock')
        self.version_tb.Text = T('up_version') % updater.read_local()['version']
        if self._update_version:
            self.update_btn.Content = T('up_button') % self._update_version
        for code, button in (('uz', self.lang_uz), ('ru', self.lang_ru), ('en', self.lang_en)):
            current = code == get_lang()
            button.FontWeight = FontWeights.Bold if current else FontWeights.Normal
            button.Opacity = 1.0 if current else 0.5

    def enable_keyboard(self):
        # modal bo'lmagan oynada matn maydonlari klaviaturani to'liq olishi uchun
        try:
            clr.AddReference('WindowsFormsIntegration')
            from System.Windows.Forms.Integration import ElementHost
            ElementHost.EnableModelessKeyboardInterop(self)
        except Exception:
            pass

    def restore_window(self):
        try:
            box = catalog.load_settings().get('window')
            left, top, width, height = [float(v) for v in box]
            inside = (left >= SystemParameters.VirtualScreenLeft
                      and top >= SystemParameters.VirtualScreenTop
                      and left + 100 < SystemParameters.VirtualScreenLeft + SystemParameters.VirtualScreenWidth
                      and top + 100 < SystemParameters.VirtualScreenTop + SystemParameters.VirtualScreenHeight)
            if inside and width >= WIDE_MIN[0] and height >= WIDE_MIN[1]:
                self.WindowStartupLocation = WindowStartupLocation.Manual
                self.Left, self.Top, self.Width, self.Height = left, top, width, height
                self._wide_box = [left, top, width, height]
        except Exception:
            pass

    # --- yangilanish ---

    def show_update(self, version):
        """Yangi versiya bo'lsa chap ustunda "Yangilash" tugmasini ko'rsatadi."""
        if version and updater.is_newer(version, updater.read_local()['version']):
            self._update_version = version
            self.update_btn.Content = T('up_button') % version
            self.update_btn.Visibility = Visibility.Visible

    def check_updates(self):
        """Kuniga bir marta, fonda: serverda yangi versiya bormi. Oyna kutib qolmaydi."""
        settings = catalog.load_settings()
        today = time.strftime('%Y-%m-%d')
        if settings.get('update_checked') == today:
            self.show_update(settings.get('update_version'))
            return

        def finish(version):
            try:
                latest = catalog.load_settings()
                latest['update_checked'] = today
                latest['update_version'] = version
                catalog.save_settings(latest)
                self.show_update(version)
            except Exception:
                pass

        def work(state):
            try:
                found = updater.check()
                version = found.version if found is not None else None
                self.Dispatcher.BeginInvoke(DispatcherPriority.Background,
                                            Action(lambda: finish(version)))
            except Exception:
                pass                    # internet yo'q yoki manzil sozlanmagan - jim o'tamiz

        try:
            ThreadPool.QueueUserWorkItem(WaitCallback(work))
        except Exception:
            pass

    # --- mavzu (ranglar) ---

    def apply_theme(self, mode=None):
        """Ranglarni almashtiradi. mode: auto | light | dark; None - rejim o'zgarmaydi,
        faqat Revit mavzusi qayta tekshiriladi ('auto' uchun)."""
        if mode is not None:
            self._theme_mode = mode if mode in theme.MODES else 'auto'
        name = theme.resolve(self._theme_mode, revit_is_dark())
        if name == self._theme:
            return
        for key, value in theme.THEMES[name].items():
            self.Resources[key] = _hex_brush(value)
        self._theme = name

    # --- yon panel rejimi ---

    def dpi_scale(self):
        """Ekran piksellaridan WPF birliklariga o'tish koeffitsiyenti (masshtab 125% va h.k.)."""
        source = PresentationSource.FromVisual(self)
        if source is None or source.CompositionTarget is None:
            return 1.0, 1.0
        matrix = source.CompositionTarget.TransformFromDevice
        return matrix.M11, matrix.M22

    def dock_box(self):
        """Yon panel joyi: Revit chizma maydonining o'ng cheti, to'liq balandlikda."""
        try:
            area = HOST_APP.uiapp.DrawingAreaExtents
            self._area = [area.Right, area.Top, area.Bottom]
        except Exception:
            pass                    # Revit hozir bermadi - oxirgi ma'lum joy ishlatiladi
        if self._area:
            right, top, bottom = self._area
            sx, sy = self.dpi_scale()
            return [right * sx - DOCK_WIDTH, top * sy, DOCK_WIDTH,
                    max((bottom - top) * sy, DOCK_MIN[1])]
        work = SystemParameters.WorkArea
        return [work.Right - DOCK_WIDTH, work.Top + 180.0, DOCK_WIDTH,
                max(work.Height - 220.0, DOCK_MIN[1])]

    def set_docked(self, docked):
        """Yon panel (tor, chizma yonida) va to'liq oyna o'rtasida almashadi."""
        if docked and not self._docked and self.WindowState == WindowState.Normal:
            self._wide_box = [self.Left, self.Top, self.Width, self.Height]
        self._docked = docked
        wide = not docked
        for element in (self.nav_panel, self.detail_panel, self.brand_tb, self.lang_panel,
                        self.status_tb):
            element.Visibility = _vis(wide)
        for element in (self.compact_bar, self.compact_status):
            element.Visibility = _vis(docked)
        self.cards_lb.ItemTemplate = self.FindResource('CardCompact' if docked else 'CardWide')
        self.cards_lb.Padding = Thickness(4, 6, 4, 0) if docked else Thickness(10, 10, 10, 0)
        self.footer_panel.Margin = Thickness(10, 0, 10, 0) if docked else Thickness(20, 0, 17, 0)
        self.apply_texts()
        self.update_footer()
        self.WindowState = WindowState.Normal
        self.WindowStartupLocation = WindowStartupLocation.Manual
        if docked:
            self.MinWidth, self.MinHeight = DOCK_MIN
            self.Left, self.Top, self.Width, self.Height = self.dock_box()
        else:
            box = self._wide_box
            if not box:
                work = SystemParameters.WorkArea
                box = [work.Left + max((work.Width - 1280.0) / 2, 0.0),
                       work.Top + max((work.Height - 760.0) / 2, 0.0), 1280.0, 760.0]
            self.Left, self.Top, self.Width, self.Height = box
            self.MinWidth, self.MinHeight = WIDE_MIN

    # --- ma'lumot ---

    def open_library(self, root):
        self._ready = False
        self.lib = catalog.Library(root)
        prepare(self.lib)
        self._bitmaps = {}
        self._tried = set()
        self._editing = []
        self._nav = ('all', None)
        self.folder_tb.Text = root
        self.folder_tb.ToolTip = root
        self._ready = True
        self.rebuild()

    def rebuild(self, message=None):
        """Chap ustun va kartochkalarni qaytadan tuzadi (tanlov saqlanadi)."""
        self.build_nav()
        self.refresh(message)

    def build_nav(self):
        lib = self.lib
        materials, pending = lib.materials()
        rows = [NavRow('all', None, T('nav_all'), len(lib.items)),
                NavRow('fav', None, T('nav_fav'), len(lib.favorites())),
                NavRow('recent', None, T('nav_recent'), len(lib.recent())),
                NavRow('materials', None, T('nav_materials'),
                       u'' if pending or not materials else len(materials))]
        rows.append(NavRow('head', None, T('head_categories')))
        for name, count in lib.categories():
            rows.append(NavRow('cat', name, name or T('unsorted'), count))
        brands = lib.brands()
        if brands:
            rows.append(NavRow('head', None, T('head_brands')))
            rows.extend(NavRow('brand', name, name, count) for name, count in brands)
        sets = lib.set_names()
        if sets:
            rows.append(NavRow('head', None, T('head_sets')))
            rows.extend(NavRow('set', name, name, len(lib.set_items(name))) for name in sets)
        index = 0
        for n, row in enumerate(rows):
            if (row.kind, row.value) == self._nav:
                index = n
        ready, self._ready = self._ready, False
        self.nav_lb.ItemsSource = rows
        self.nav_lb.SelectedIndex = index
        self.nav_cb.ItemsSource = [r for r in rows if r.enabled]    # yon panelda: ro'yxat o'rniga
        self.nav_cb.SelectedItem = rows[index]
        self._nav = (rows[index].kind, rows[index].value)
        self._ready = ready

    def in_materials(self):
        return self._nav[0] == 'materials'

    def refresh(self, message=None, keep_selection=True):
        kind, value = self._nav
        query = self.search_tb.Text.strip()
        keep = set(c.key for c in self.selected()) if keep_selection else set()
        empty = T('empty_search')
        if kind == 'materials':
            materials, pending = self.lib.materials()
            todo = [p for p in pending if p not in self._tried]
            if todo and not self._reading:
                self.read_materials(todo)
            cards = [MaterialCard(m) for m in materials if m.matches(query)]
            self._total = len(cards)
            if self._reading:
                empty = T('reading_materials')
                message = message or T('queued')
            elif not materials:
                empty = T('empty_materials')
        else:
            found = self.lib.find(kind, value, query)
            favorites = self.lib.favorite_keys()
            self._total = len(found)
            cards = [Card(i, i.key in favorites, self._bitmaps) for i in found[:MAX_CARDS]]
            if not self.lib.items:
                empty = T('empty_library')
            elif kind == 'fav' and not query:
                empty = T('empty_fav')
            elif kind == 'recent' and not query:
                empty = T('empty_recent')
        ready, self._ready = self._ready, False
        self.cards_lb.ItemsSource = cards
        for card in cards:
            if card.key in keep:
                self.cards_lb.SelectedItems.Add(card)
        self._ready = ready
        self.empty_tb.Text = empty
        self.empty_tb.Visibility = _vis(not cards)
        self.update_detail()
        self.update_footer(message)

    def selected(self):
        return list(self.cards_lb.SelectedItems)

    def selected_items(self):
        return [c.item for c in self.selected() if not c.is_material]

    def selected_type(self):
        row = self.types_lb.SelectedItem
        if row is not None and self.types_lb.Visibility == Visibility.Visible:
            return row.name
        return None

    # --- pastki qator ---

    def update_footer(self, message=None):
        picked = self.selected()
        shown = self.cards_lb.Items.Count
        materials = self.in_materials()
        whole_set = self._nav[0] == 'set' and not picked and shown > 0
        short = '_short' if self._docked else ''      # yon panelda tugma matnlari qisqa
        self.load_btn.Content = ((T('btn_load_set' + short) % shown) if whole_set
                                 else T('btn_load' + short))
        self.load_btn.IsEnabled = len(picked) > 0 or whole_set
        self.place_btn.Content = T('btn_apply' + short) if materials else T('btn_place')
        self.place_btn.IsEnabled = len(picked) == 1
        if message:
            self.say(message)
        elif len(picked) == 1:
            self.say(picked[0].title)
        elif picked:
            self.say(T('count_selected') % len(picked))
        elif materials:
            self.say(T('count_materials') % shown)
        elif shown < self._total:
            self.say(T('count_shown') % (shown, self._total))
        else:
            self.say(T('count_models') % shown)

    # --- o'ng ustun: model sahifasi ---

    def update_detail(self):
        picked = self.selected()
        if self._editing:
            self._editing = []
        self.edit_view.Visibility = Visibility.Collapsed
        self.detail_empty.Visibility = _vis(not picked)
        self.detail_view.Visibility = _vis(bool(picked))
        if not picked:
            return
        single = len(picked) == 1
        material = picked[0].is_material
        model = not material
        for element in (self.d_image_box, self.d_info):
            element.Visibility = _vis(single)
        for element in (self.fav_btn, self.set_btn, self.edit_btn):
            element.Visibility = _vis(model)
        self.d_sub.Visibility = _vis(single)
        self.d_warn.Visibility = Visibility.Collapsed
        self.d_desc.Visibility = Visibility.Collapsed
        self.d_tags.Visibility = Visibility.Collapsed
        self.show_types([])
        if model:
            items = [c.item for c in picked]
            favorites = self.lib.favorite_keys()
            all_fav = all(i.key in favorites for i in items)
            self.fav_btn.Content = T('fav_remove') if all_fav else T('fav_add')
            in_set = self._nav[0] == 'set'
            self.set_btn.Content = T('btn_remove_set') if in_set else T('btn_add_set')
        if not single:
            self.d_title.Text = T('count_selected') % len(picked)
            return
        card = picked[0]
        self.d_title.Text = card.title
        self.d_sub.Text = card.sub
        self.d_image.Visibility = _vis(model)
        self.d_swatch.Visibility = _vis(material)
        if material:
            mat = card.material
            self.d_swatch.Background = card.swatch
            self.d_info.ItemsSource = [InfoRow(T('info_class'), mat.material_class or u'-'),
                                       InfoRow(T('info_collection'), mat.collection)]
            return
        item = card.item
        self.d_image.Source = _bitmap(item.thumb_path, 512)
        if card.too_new:
            self.d_warn.Text = T('err_newer') % (item.year, HOST_YEAR)
            self.d_warn.Visibility = Visibility.Visible
        info = []
        if item.brand:
            info.append(InfoRow(T('info_brand'), item.brand))
        if item.revit_category:
            info.append(InfoRow(T('info_category'), item.revit_category))
        if item.year:
            info.append(InfoRow(T('info_revit'), u'%d' % item.year))
        info.append(InfoRow(T('info_size'), _size_text(item.size)))
        self.d_info.ItemsSource = info
        if item.description:
            self.d_desc.Text = item.description
            self.d_desc.Visibility = Visibility.Visible
        if item.tags:
            self.d_tags.Text = u'   '.join(u'#' + t for t in item.tags)
            self.d_tags.Visibility = Visibility.Visible
        self.show_types(item.types)

    def show_types(self, types):
        rows = [TypeRow(t) for t in types]
        self.types_lb.ItemsSource = rows
        several = len(rows) > 1
        self.types_head.Visibility = _vis(several)
        self.types_lb.Visibility = _vis(several)
        if rows:
            self.types_lb.SelectedIndex = 0
        self.show_dims(rows[0] if rows else None)

    def show_dims(self, row):
        params = row.params if row is not None else []
        self.dims_ic.ItemsSource = [InfoRow(name, value) for name, value in params]
        self.dims_head.Visibility = _vis(bool(params))
        self.dims_ic.Visibility = _vis(bool(params))

    # --- o'ng ustun: muharrir ---

    def start_edit(self, items):
        self._editing = items
        single = len(items) == 1
        first = items[0]
        self.e_head.Text = first.title if single else T('count_selected') % len(items)
        self.e_note.Text = first.rel if single else T('edit_many') % len(items)
        self.e_title.IsEnabled = single
        self.e_desc.IsEnabled = single
        self.e_title.Text = first.title if single else u''
        self.e_desc.Text = first.description if single else u''
        self.e_brand.Text = first.brand if single else u''
        self.e_tags.Text = u', '.join(first.tags) if single else u''
        self.e_tags_label.Text = T('edit_tags') if single else T('edit_tags_add')
        self.e_pro.IsThreeState = not single
        if single:
            self.e_pro.IsChecked = first.is_pro
        else:
            self.e_pro.IsChecked = None       # belgilanmagan = o'zgarmaydi
        self.detail_view.Visibility = Visibility.Collapsed
        self.edit_view.Visibility = Visibility.Visible

    def save_edit(self):
        items = self._editing
        tags = [t.strip() for t in self.e_tags.Text.split(',') if t.strip()]
        pro = self.e_pro.IsChecked
        try:
            if len(items) == 1:
                self.lib.update_meta(items, title=self.e_title.Text, brand=self.e_brand.Text,
                                     tags=tags, description=self.e_desc.Text, pro=bool(pro))
            else:
                self.lib.update_meta(items, brand=self.e_brand.Text.strip() or None,
                                     add_tags=tags or None, pro=pro)
        except catalog.CatalogError as err:
            key = 'err_catalog_broken' if '%s' % err == 'broken' else 'err_catalog_readonly'
            forms.alert(T(key), title=APP)
            return
        self._editing = []
        self.rebuild(T('saved'))

    # --- materiallar ---

    def read_materials(self, paths):
        self._reading = True
        self._tried.update(paths)

        def job(uiapp):
            errors = []
            try:
                for path in paths:
                    try:
                        records = read_materials(uiapp.Application, path)
                    except Exception as err:
                        records = []
                        errors.append(u'%s: %s' % (os.path.basename(path), err))
                    self.lib.store_materials(path, records)
            finally:
                self._reading = False
            self.rebuild()
            if errors:
                forms.alert(T('err_material_file'), sub_msg=u'\n'.join(errors), title=APP)

        self.run(job)

    # --- Revit navbatida bajariladigan ishlar ---

    def job_load(self, uiapp, items, place=False, type_name=None):
        uidoc = uiapp.ActiveUIDocument
        if uidoc is None:
            self.say(T('no_document'))
            return
        doc = uidoc.Document
        families, loaded, existed, failed = load_items(doc, items)
        used = [i for i in items if i.key in families]
        message = summary(loaded, existed, failed)
        if used:
            self.lib.touch_recent(used)
        if place and used:
            symbol = prepare_symbol(doc, used[0], families[used[0].key], type_name)
            if symbol is None:
                message = T('err_no_type')
            else:
                try:
                    uidoc.PostRequestForElementTypePlacement(symbol)
                    message = T('done_placing') % used[0].title
                except Exception:
                    forms.alert(T('err_not_placeable'), title=APP)
        if used:
            self.build_nav()
            if self._nav[0] == 'recent':
                self.refresh()
        self.update_footer(message)
        if failed:
            forms.alert(u'\n'.join(u'%s: %s' % pair for pair in failed), title=APP)

    def job_materials(self, uiapp, materials, apply_first=False):
        uidoc = uiapp.ActiveUIDocument
        if uidoc is None:
            self.say(T('no_document'))
            return
        doc = uidoc.Document
        loaded, existed, failed = import_materials(uiapp.Application, doc, materials)
        self.update_footer(summary(loaded, existed, failed))
        if failed:
            forms.alert(u'\n'.join(u'%s: %s' % pair for pair in failed), title=APP)
        if apply_first and not failed:
            material = _named(doc, DB.Material).get(materials[0].name)
            if material is not None:
                self.say(T('pick_face'))
                self.update_footer(T('done_painted') % paint_faces(uidoc, material))

    # --- hodisalar ---

    @safe
    def on_search(self, sender, args):
        self.search_hint.Visibility = _vis(not self.search_tb.Text)
        if self._ready:
            self.refresh()

    @safe
    def on_nav(self, sender, args):
        row = self.nav_lb.SelectedItem
        if self._ready and row is not None:
            self._nav = (row.kind, row.value)
            self._ready = False
            self.nav_cb.SelectedItem = row
            self._ready = True
            self.refresh(keep_selection=False)     # boshqa bo'limga o'tganda tanlov tozalanadi

    @safe
    def on_nav_combo(self, sender, args):
        row = self.nav_cb.SelectedItem
        if self._ready and row is not None:
            self._nav = (row.kind, row.value)
            self._ready = False
            self.nav_lb.SelectedItem = row          # chap ro'yxat ham shu bo'limda tursin
            self._ready = True
            self.refresh(keep_selection=False)

    @safe
    def on_activated(self, sender, args):
        # Mavzu va til "Sozlamalar" oynasida tanlanadi; oynaga qaytilganda qayta o'qiymiz.
        settings = catalog.load_settings()
        self.apply_theme(settings.get('theme'))     # 'auto' bo'lsa Revit mavzusiga ergashadi
        code = settings.get('lang')
        if code in LANGS and code != get_lang():
            set_lang(code)
            self.apply_texts()
            self.rebuild()

    @safe
    def on_update(self, sender, args):
        self.run(lambda uiapp: run_update_flow())

    @safe
    def on_dock(self, sender, args):
        self.set_docked(not self._docked)
        settings = catalog.load_settings()
        settings['docked'] = self._docked
        catalog.save_settings(settings)

    @safe
    def on_select(self, sender, args):
        if self._ready:
            self.update_detail()
            self.update_footer()

    @safe
    def on_type(self, sender, args):
        self.show_dims(self.types_lb.SelectedItem)

    @safe
    def on_lang(self, sender, args):
        code = (u'%s' % sender.Content).lower()
        if code in LANGS and code != get_lang():
            set_lang(code)
            settings = catalog.load_settings()
            settings['lang'] = code
            catalog.save_settings(settings)
            self.apply_texts()
            self.rebuild()

    @safe
    def on_folder(self, sender, args):
        root = forms.pick_folder(title=T('pick_folder'))
        if root:
            settings = catalog.load_settings()
            settings['library'] = root
            catalog.save_settings(settings)
            self.open_library(root)

    @safe
    def on_load(self, sender, args):
        picked = self.selected()
        if self.in_materials():
            materials = [c.material for c in picked]
            if materials:
                self.run(lambda uiapp: self.job_materials(uiapp, materials))
            return
        if not picked and self._nav[0] == 'set':
            picked = list(self.cards_lb.ItemsSource)        # to'plamning hammasi
        items = [c.item for c in picked]
        if items:
            self.run(lambda uiapp: self.job_load(uiapp, items))

    @safe
    def on_place(self, sender, args):
        picked = self.selected()
        if len(picked) != 1:
            return
        if picked[0].is_material:
            materials = [picked[0].material]
            self.run(lambda uiapp: self.job_materials(uiapp, materials, apply_first=True))
        else:
            items = [picked[0].item]
            type_name = self.selected_type()
            self.run(lambda uiapp: self.job_load(uiapp, items, place=True, type_name=type_name))

    @safe
    def on_double_click(self, sender, args):
        hit = ItemsControl.ContainerFromElement(self.cards_lb, args.OriginalSource)
        if hit is not None:
            self.on_place(sender, args)

    @safe
    def on_favorite(self, sender, args):
        items = self.selected_items()
        if items:
            self.lib.toggle_favorite(items)
            self.rebuild()

    @safe
    def on_set(self, sender, args):
        items = self.selected_items()
        if not items:
            return
        try:
            if self._nav[0] == 'set':
                self.lib.remove_from_set(self._nav[1], items)
            else:
                name = self.ask_set_name()
                if not name:
                    return
                self.lib.add_to_set(name, items)
        except catalog.CatalogError as err:
            key = 'err_catalog_broken' if '%s' % err == 'broken' else 'err_catalog_readonly'
            forms.alert(T(key), title=APP)
            return
        self.rebuild(T('saved'))

    def ask_set_name(self):
        names = self.lib.set_names()
        choice = None
        if names:
            choice = forms.SelectFromList.show(names + [T('new_set')], title=T('ask_set'),
                                               multiselect=False)
            if not choice:
                return None
        if choice is None or choice == T('new_set'):
            choice = forms.ask_for_string(default=u'', prompt=T('ask_set_name'), title=APP)
        return (choice or u'').strip()

    @safe
    def on_edit(self, sender, args):
        items = self.selected_items()
        if items:
            self.start_edit(items)

    @safe
    def on_save(self, sender, args):
        if self._editing:
            self.save_edit()

    @safe
    def on_cancel(self, sender, args):
        self.update_detail()

    @safe
    def on_closed(self, sender, args):
        script.set_envvar(WINDOW_VAR, None)
        box = self._wide_box
        if not self._docked and self.WindowState == WindowState.Normal:
            box = [self.Left, self.Top, self.Width, self.Height]
        settings = catalog.load_settings()
        settings['docked'] = self._docked
        if box:
            settings['window'] = box
        catalog.save_settings(settings)


# --- ishga tushirish ---------------------------------------------------------

def library_root(settings):
    """Saqlangan kutubxona papkasi; bo'lmasa foydalanuvchidan so'raydi."""
    root = settings.get('library')
    if root and os.path.isdir(root):
        return root
    root = forms.pick_folder(title=T('pick_folder'))
    if root:
        settings['library'] = root
        catalog.save_settings(settings)
    return root


def main():
    # oyna allaqachon ochiq bo'lsa, yangisini ochmaymiz - borini oldinga chiqaramiz
    try:
        opened = script.get_envvar(WINDOW_VAR)
        if opened is not None and opened.IsVisible:
            if opened.WindowState == WindowState.Minimized:
                opened.WindowState = WindowState.Normal
            opened.Activate()
            return
    except Exception:
        pass
    settings = catalog.load_settings()
    set_lang(settings.get('lang'))
    root = library_root(settings)
    if not root:
        return
    dispatcher = Dispatcher()
    event = UI.ExternalEvent.Create(dispatcher)
    window = CatalogWindow(root, dispatcher, event)
    script.set_envvar(WINDOW_VAR, window)
    window.show()
    if settings.get('docked'):
        try:
            window.set_docked(True)   # o'tgan safar yon panel rejimida yopilgan
        except Exception:
            report(traceback.format_exc())


main()
