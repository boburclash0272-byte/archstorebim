# -*- coding: utf-8 -*-
"""ArchStore BIM - Pol.

Ochiq turgan qavat rejasidagi (yoki tanlangan) xonalarga bir yo'la pol yaratadi:
har xonaga o'z pol turi, pol eshik o'rinlarida devorning yarmigacha kiradi."""

__title__ = 'Pol'
__author__ = 'ArchStore BIM'

import clr

clr.AddReference('WindowsBase')
clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')

from System import Guid, String
from System.Collections.Generic import List
from System.Windows import Point
from System.Windows.Controls import Canvas, TextBlock
from System.Windows.Media import PointCollection
from System.Windows.Shapes import Polygon

from pyrevit import DB, forms, revit
from Autodesk.Revit.DB.ExtensibleStorage import AccessLevel, Entity, Schema, SchemaBuilder

from archstore import catalog, floors
from archstore.i18n import T, set_lang
from archstore.rvt import Tx
from archstore.ui import APP, ToolWindow, hex_brush, safe

# Shu asbob yaratgan pollar "qaysi xona uchun" belgisini shu sxemada saqlaydi
# (foydalanuvchi parametrlariga tegilmaydi). Keyingi safar "almashtirish" /
# "o'tkazib yuborish" faqat shunday belgilangan pollarga taalluqli.
SCHEMA_ID = Guid('8a0f6f0b-5d2b-4f5a-9b0e-6c1d7e2a4b31')
DEFAULT_DOOR_WIDTH = 900.0 / floors.MM_PER_FT
LABEL_COLOR = '#1B1B19'
OUTLINE_COLOR = '#55524A'


# --- loyihadan ma'lumot yig'ish ----------------------------------------------

def target_rooms(doc, uidoc):
    """Tanlangan xonalar; tanlanmagan bo'lsa - ochiq rejaning qavatidagi hamma xonalar.
    Reja ochiq bo'lmasa va xona tanlanmagan bo'lsa None qaytaradi."""
    picked = [doc.GetElement(i) for i in uidoc.Selection.GetElementIds()]
    rooms = [e for e in picked if isinstance(e, DB.Architecture.Room) and e.Area > 0]
    if rooms:
        return rooms
    level = getattr(doc.ActiveView, 'GenLevel', None)
    if level is None:
        return None
    everything = (DB.FilteredElementCollector(doc)
                  .OfCategory(DB.BuiltInCategory.OST_Rooms)
                  .WhereElementIsNotElementType())
    return [r for r in everything if r.Area > 0 and r.LevelId == level.Id]


def floor_types(doc):
    """{nom: FloorType} - poydevor plitalari kirmaydi."""
    found = {}
    for kind in DB.FilteredElementCollector(doc).OfClass(DB.FloorType):
        try:
            if kind.IsFoundationSlab:
                continue
        except Exception:
            pass
        found[revit.query.get_name(kind)] = kind
    return found


def room_outline(room):
    """Preview uchun: (konturlar [[(x, y), ...], ...] tashqisi birinchi, z balandlik)."""
    loops, z = [], None
    for segments in room.GetBoundarySegments(DB.SpatialElementBoundaryOptions()):
        points = []
        for segment in segments:
            tess = list(segment.GetCurve().Tessellate())
            if z is None and tess:
                z = tess[0].Z
            points.extend((p.X, p.Y) for p in tess[:-1])
        points = floors.dedupe(points)
        if len(points) >= 3:
            loops.append(points)
    loops.sort(key=floors.polygon_area, reverse=True)
    return loops, z


def room_name(room):
    param = room.get_Parameter(DB.BuiltInParameter.ROOM_NAME)
    return (param.AsString() if param is not None else None) or u''


def make_rows(rooms):
    """(qatorlar, {UniqueId: xona}, {UniqueId: z})"""
    rows, by_key, heights = [], {}, {}
    none = T('fl_none')
    for room in rooms:
        loops, z = room_outline(room)
        if not loops:
            continue
        location = room.Location
        if isinstance(location, DB.LocationPoint):
            label = (location.Point.X, location.Point.Y)
        else:
            label = floors.centroid(loops[0])
        key = room.UniqueId
        rows.append(floors.RoomRow(key, room.Number, room_name(room), room.Area, loops, label, none))
        by_key[key] = room
        heights[key] = z
    rows.sort(key=lambda r: floors.number_key(r.number))
    return rows, by_key, heights


def door_width(door):
    for owner in (door, door.Symbol):
        for name in ('DOOR_WIDTH', 'FAMILY_WIDTH_PARAM', 'GENERIC_WIDTH'):
            try:
                param = owner.get_Parameter(getattr(DB.BuiltInParameter, name))
                if param is not None and param.HasValue and param.AsDouble() > 0:
                    return param.AsDouble()
            except Exception:
                pass
    return DEFAULT_DOOR_WIDTH


def collect_openings(doc, rows, by_key, heights):
    """Har bir eshikning ikki tomonidagi xonani topib, o'sha xonaga eshik o'rnini
    (devor o'qigacha bo'lgan to'rtburchakni) biriktiradi."""
    row_by_key = dict((r.key, r) for r in rows)
    doors = (DB.FilteredElementCollector(doc)
             .OfCategory(DB.BuiltInCategory.OST_Doors)
             .WhereElementIsNotElementType())
    for door in doors:
        try:
            wall = door.Host
            location = door.Location
            if not isinstance(wall, DB.Wall) or not isinstance(location, DB.LocationPoint):
                continue
            axis = wall.Location.Curve
            if not isinstance(axis, DB.Line):
                continue                      # egri devorlar hozircha hisobga olinmaydi
            direction = axis.Direction
            origin = axis.GetEndPoint(0)
            point = location.Point
            along = (point.X - origin.X) * direction.X + (point.Y - origin.Y) * direction.Y
            center = (origin.X + direction.X * along, origin.Y + direction.Y * along)
            width = door_width(door)
            thickness = wall.Width
            for side in (1, -1):
                reach = thickness / 2.0 + 0.5
                x = center[0] - direction.Y * side * reach
                y = center[1] + direction.X * side * reach
                for key, room in by_key.items():
                    if door.LevelId != room.LevelId:
                        continue
                    if room.IsPointInRoom(DB.XYZ(x, y, heights[key] + 1.0)):
                        row_by_key[key].openings.append(floors.opening_rect(
                            center, (direction.X, direction.Y), width, thickness, side))
                        break
        except Exception:
            continue


# --- pol yaratish ------------------------------------------------------------

def polyline_loop(points, z):
    loop = DB.CurveLoop()
    count = len(points)
    for i in range(count):
        a, b = points[i], points[(i + 1) % count]
        loop.Append(DB.Line.CreateBound(DB.XYZ(a[0], a[1], z), DB.XYZ(b[0], b[1], z)))
    return loop


def room_loops(room, row, z):
    """Xona konturi Revit egri chiziqlari bilan; ulanmay qolsa - siniq chiziq bilan."""
    loops = []
    for segments in room.GetBoundarySegments(DB.SpatialElementBoundaryOptions()):
        try:
            loop = DB.CurveLoop()
            for segment in segments:
                loop.Append(segment.GetCurve())
            if loop.IsOpen():
                raise ValueError('open loop')
            loops.append(loop)
        except Exception:
            # aniq egri chiziqlar ulanmadi - shu xonaning hamma konturini siniq chiziq bilan olamiz
            return [polyline_loop(points, z) for points in row.loops]
    return loops


def as_list(loops):
    result = List[DB.CurveLoop]()
    for loop in loops:
        result.Add(loop)
    return result


def with_openings(loops, rectangles, z):
    """Xona konturiga eshik o'rinlarini qo'shadi (Revit'ning o'z geometriyasi bilan birlashtirib)."""
    up = DB.XYZ.BasisZ
    solid = DB.GeometryCreationUtilities.CreateExtrusionGeometry(as_list(loops), up, 1.0)
    for rectangle in rectangles:
        piece = DB.GeometryCreationUtilities.CreateExtrusionGeometry(
            as_list([polyline_loop(rectangle, z)]), up, 1.0)
        solid = DB.BooleanOperationsUtils.ExecuteBooleanOperation(
            solid, piece, DB.BooleanOperationsType.Union)
    for face in solid.Faces:
        if isinstance(face, DB.PlanarFace) and face.FaceNormal.Z < -0.99:
            return list(face.GetEdgesAsCurveLoops())
    raise ValueError('bottom face not found')


def create_floor(doc, loops, floor_type, level):
    if hasattr(DB.Floor, 'Create'):                    # Revit 2022 va undan yangi
        return DB.Floor.Create(doc, as_list(loops), floor_type.Id, level.Id)
    curves = DB.CurveArray()                           # eski Revit: faqat tashqi kontur
    for curve in loops[0]:
        curves.Append(curve)
    return doc.Create.NewFloor(curves, floor_type, level, False)


def tag_field():
    """(sxema, maydon) - pol qaysi xonaga tegishli ekanini saqlash uchun."""
    schema = Schema.Lookup(SCHEMA_ID)
    if schema is None:
        builder = SchemaBuilder(SCHEMA_ID)
        builder.SetReadAccessLevel(AccessLevel.Public)
        builder.SetWriteAccessLevel(AccessLevel.Public)
        builder.SetSchemaName('ArchStoreBimFloor')
        builder.AddSimpleField('RoomId', clr.GetClrType(String))
        schema = builder.Finish()
    return schema, schema.GetField('RoomId')


def tagged_floors(doc, schema, field):
    """{xona UniqueId: [shu asbob yaratgan pol Id'lari]}"""
    found = {}
    for floor in DB.FilteredElementCollector(doc).OfClass(DB.Floor):
        entity = floor.GetEntity(schema)
        if entity.IsValid():
            found.setdefault(entity.Get[String](field), []).append(floor.Id)
    return found


def build(doc, rows, by_key, heights, types, use_openings, replace, offset_mm):
    """Pollarni yaratadi. Qaytaradi: (yaratilgan soni, o'tkazib yuborilgan soni,
    eshik o'rni qo'shilmagan xonalar, [xato bo'lgan xona: sabab])."""
    created, skipped, plain, failed = 0, 0, [], []
    try:
        schema, field = tag_field()
        existing = tagged_floors(doc, schema, field)
    except Exception:
        schema, field, existing = None, None, {}
    offset = offset_mm / floors.MM_PER_FT
    with Tx(doc, APP + u': pol'):
        for row in rows:
            if not row.ready:
                continue
            room = by_key[row.key]
            old = existing.get(row.key, [])
            if old and not replace:
                skipped += 1
                continue
            step = DB.SubTransaction(doc)
            step.Start()
            try:
                z = heights[row.key]
                loops = room_loops(room, row, z)
                if use_openings and row.openings:
                    try:
                        loops = with_openings(loops, row.openings, z)
                    except Exception:
                        plain.append(row.title)
                floor = create_floor(doc, loops, types[row.type_name], doc.GetElement(room.LevelId))
                param = floor.get_Parameter(DB.BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM)
                if param is not None and not param.IsReadOnly:
                    param.Set(offset)
                if schema is not None:
                    entity = Entity(schema)
                    entity.Set[String](field, row.key)
                    floor.SetEntity(entity)
                for floor_id in old:                   # yangisi tayyor - eskisini o'chiramiz
                    doc.Delete(floor_id)
                step.Commit()
                created += 1
            except Exception as err:
                step.RollBack()
                failed.append(u'%s: %s' % (row.title, err))
    return created, skipped, plain, failed


# --- oyna --------------------------------------------------------------------

class FloorWindow(ToolWindow):
    def __init__(self, rows, type_names):
        ToolWindow.__init__(self)
        self.rows = rows
        self.accepted = False
        self.offset_mm = 0.0
        self.use_openings = True
        self.replace = True
        self._ready = False
        self._brushes = {}

        self.title_tb.Text = T('fl_title')
        self.sub_tb.Text = T('fl_sub') % len(rows)
        self.hint_tb.Text = T('fl_hint')
        self.all_label.Text = T('fl_all')
        self.apply_btn.Content = T('fl_apply')
        self.rooms_label.Text = T('fl_rooms')
        self.remember_tb.Text = T('fl_remember')
        self.params_label.Text = T('fl_params')
        self.openings_cb.Content = T('fl_openings')
        self.openings_sub.Text = T('fl_openings_sub')
        self.exists_tb.Text = T('fl_exists')
        self.replace_rb.Content = T('fl_replace')
        self.skip_rb.Content = T('fl_skip')
        self.offset_label.Text = T('fl_offset')
        self.preview_label.Text = T('fl_preview')
        self.preview_note.Text = T('fl_preview_note')
        self.cancel_btn.Content = T('btn_cancel')

        choices = [T('fl_none')] + type_names
        for row in rows:
            row.types = choices
            row._on_change = self.on_row_change
        self.all_cb.ItemsSource = choices
        self.all_cb.SelectedIndex = 0
        self.rooms_lb.ItemsSource = rows

        self.apply_btn.Click += self.on_apply
        self.ok_btn.Click += self.on_ok
        self.cancel_btn.Click += self.on_cancel
        self.openings_cb.Click += self.on_option
        self.preview_cv.SizeChanged += self.on_option
        self._ready = True
        self.update()

    def update(self):
        count = len([r for r in self.rows if r.ready])
        self.ok_btn.Content = (T('fl_create_n') % count) if count else T('fl_create')
        self.ok_btn.IsEnabled = count > 0
        self.draw()

    # --- oldindan ko'rish ---

    def brush(self, color):
        if color not in self._brushes:
            self._brushes[color] = hex_brush(color)
        return self._brushes[color]

    def add_polygon(self, points, transform, fill, stroke, opacity=1.0):
        shape = Polygon()
        corners = PointCollection()
        for point in points:
            x, y = floors.to_canvas(point, transform)
            corners.Add(Point(x, y))
        shape.Points = corners
        shape.Fill = fill
        shape.Stroke = stroke
        shape.StrokeThickness = 1.0
        shape.Opacity = opacity
        self.preview_cv.Children.Add(shape)

    def draw(self):
        canvas = self.preview_cv
        canvas.Children.Clear()
        width, height = canvas.ActualWidth, canvas.ActualHeight
        box = floors.bounds(self.rows)
        if box is None or width < 40 or height < 40:
            return
        transform = floors.fit(box, width, height)
        colors = floors.type_colors(self.rows)
        outline = self.brush(OUTLINE_COLOR)
        hole = self.Resources['Thumb']
        for row in self.rows:
            color = colors.get(row.type_name) if row.ready else None
            fill = self.brush(color or floors.NO_TYPE_COLOR)
            for n, loop in enumerate(row.loops):
                self.add_polygon(loop, transform, fill if n == 0 else hole, outline)
        if self.openings_cb.IsChecked:
            red = self.brush(floors.OPENING_COLOR)
            for row in self.rows:
                if row.ready:
                    for rectangle in row.openings:
                        self.add_polygon(rectangle, transform, red, red, 0.75)
        ink = self.brush(LABEL_COLOR)
        for row in self.rows:
            if row.label is None or not row.name:
                continue
            text = TextBlock()
            text.Text = row.name
            text.FontSize = 10
            text.Foreground = ink
            text.Opacity = 1.0 if row.ready else 0.5
            x, y = floors.to_canvas(row.label, transform)
            Canvas.SetLeft(text, x - len(row.name) * 2.6)
            Canvas.SetTop(text, y - 7)
            canvas.Children.Add(text)

    # --- hodisalar ---

    def on_row_change(self):
        if self._ready:
            try:
                self.update()
            except Exception:
                pass

    @safe
    def on_option(self, sender, args):
        if self._ready:
            self.draw()

    @safe
    def on_apply(self, sender, args):
        choice = self.all_cb.SelectedItem
        self._ready = False
        for row in self.rows:
            if row.checked:
                row.type_item = choice
        self._ready = True
        self.rooms_lb.Items.Refresh()
        self.update()

    @safe
    def on_ok(self, sender, args):
        offset = floors.parse_offset(self.offset_tb.Text)
        if offset is None:
            forms.alert(T('fl_bad_offset'), title=APP)
            return
        self.offset_mm = offset
        self.use_openings = bool(self.openings_cb.IsChecked)
        self.replace = bool(self.replace_rb.IsChecked)
        self.accepted = True
        self.Close()

    @safe
    def on_cancel(self, sender, args):
        self.Close()


# --- ishga tushirish ---------------------------------------------------------

def main():
    doc, uidoc = revit.doc, revit.uidoc
    settings = catalog.load_settings()
    set_lang(settings.get('lang'))

    rooms = target_rooms(doc, uidoc)
    if rooms is None:
        forms.alert(T('fl_no_plan'), title=APP)
        return
    rows, by_key, heights = make_rows(rooms)
    if not rows:
        forms.alert(T('fl_no_rooms'), title=APP)
        return
    types = floor_types(doc)
    if not types:
        forms.alert(T('fl_no_types'), title=APP)
        return
    names = sorted(types, key=lambda n: n.lower())
    floors.apply_remembered(rows, settings, names)
    collect_openings(doc, rows, by_key, heights)

    window = FloorWindow(rows, names)
    window.show_dialog()
    if not window.accepted:
        return

    created, skipped, plain, failed = build(doc, rows, by_key, heights, types,
                                            window.use_openings, window.replace, window.offset_mm)
    catalog.save_settings(floors.remember(rows, catalog.load_settings()))

    lines = []
    if skipped:
        lines.append(T('fl_skipped') % skipped)
    if plain:
        lines.append(T('fl_plain') % len(plain))
        lines.extend(u'   ' + title for title in plain)
    if failed:
        lines.append(T('fl_failed') % len(failed))
        lines.extend(u'   ' + text for text in failed)
    forms.alert(T('fl_done') % created, sub_msg=u'\n'.join(lines) or None, title=APP,
                warn_icon=bool(failed))


main()
