# -*- coding: utf-8 -*-
"""ArchStore BIM - Nomerator.

List raqamlarini o'zgartiradi: listni ro'yxatda tepaga yoki pastga surasiz - u
o'sha o'rindagi raqamni oladi; yoki tanlangan listlarga boshlang'ich raqamdan
ketma-ket raqam berasiz. Loyihaga faqat "Saqlash" bosilganda yoziladi."""

__title__ = 'Nomerator'
__author__ = 'ArchStore BIM'

import clr

clr.AddReference('WindowsBase')
clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')

from pyrevit import DB, forms, revit

from archstore import catalog, numerator
from archstore.i18n import T, set_lang
from archstore.rvt import Tx
from archstore.ui import APP, ToolWindow, safe


# --- loyihadan ma'lumot yig'ish ----------------------------------------------

def collect_sheets(doc):
    """(qatorlar, {UniqueId: list})"""
    rows, by_key = [], {}
    for sheet in DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet):
        name = revit.query.get_name(sheet)
        try:
            if sheet.IsPlaceholder:
                name = u'%s %s' % (name, T('nm_placeholder'))
        except Exception:
            pass
        key = sheet.UniqueId
        rows.append(numerator.SheetRow(key, sheet.SheetNumber, name))
        by_key[key] = sheet
    return rows, by_key


def selected_sheet_keys(doc, uidoc, by_key):
    """Loyiha brauzerida tanlab qo'yilgan listlar."""
    keys = []
    try:
        for element_id in uidoc.Selection.GetElementIds():
            element = doc.GetElement(element_id)
            if isinstance(element, DB.ViewSheet) and element.UniqueId in by_key:
                keys.append(element.UniqueId)
    except Exception:
        pass
    return keys


def apply_numbers(doc, changes, by_key, taken):
    """Raqamlarni yozadi. Ikki bosqichda: avval vaqtincha raqamlar, keyin yangilari -
    shunda ikki list raqam almashganda Revit "bunday raqam bor" demaydi."""
    temporary = numerator.temp_numbers(len(changes), taken)
    with Tx(doc, APP + u': list raqamlari'):
        for (key, old, new), temp in zip(changes, temporary):
            by_key[key].SheetNumber = temp
        for key, old, new in changes:
            by_key[key].SheetNumber = new


# --- oyna --------------------------------------------------------------------

class NumberWindow(ToolWindow):
    def __init__(self, board, preselected):
        ToolWindow.__init__(self)
        self.board = board
        self.accepted = False
        self._ready = False
        self._typed = False                 # boshlang'ich raqamni foydalanuvchi o'zi yozdimi
        self._notice = u''

        self.title_tb.Text = T('nm_title')
        self.sub_tb.Text = T('nm_sub') % len(board.rows)
        self.hint_tb.Text = T('nm_hint')
        self.sheets_label.Text = T('nm_sheets')
        self.move_label.Text = T('nm_move')
        self.up_btn.Content = T('nm_up')
        self.down_btn.Content = T('nm_down')
        self.top_btn.Content = T('nm_top')
        self.bottom_btn.Content = T('nm_bottom')
        self.renumber_label.Text = T('nm_renumber')
        self.apply_btn.Content = T('fl_apply')
        self.renumber_note.Text = T('nm_renumber_note')
        self.all_btn.Content = T('nm_select_all')
        self.reset_btn.Content = T('nm_reset')
        self.cancel_btn.Content = T('btn_cancel')

        self.sheets_lb.ItemsSource = board.rows     # shu ro'yxatning o'zi o'zgaradi, keyin Refresh
        self.sheets_lb.SelectionChanged += self.on_select
        self.start_tb.TextChanged += self.on_start_typed
        self.up_btn.Click += self.on_up
        self.down_btn.Click += self.on_down
        self.top_btn.Click += self.on_top
        self.bottom_btn.Click += self.on_bottom
        self.apply_btn.Click += self.on_apply
        self.all_btn.Click += self.on_all
        self.reset_btn.Click += self.on_reset
        self.ok_btn.Click += self.on_ok
        self.cancel_btn.Click += self.on_cancel
        self.redraw(preselected)

    # --- holat ---

    def selected_keys(self):
        return [row.key for row in self.sheets_lb.SelectedItems]

    def redraw(self, keys, reveal_last=False):
        """Ro'yxatni qayta chizadi va tanlovni tiklaydi."""
        self._ready = False
        try:
            self.sheets_lb.Items.Refresh()
            picked = self.board.picked(keys)
            chosen = self.sheets_lb.SelectedItems
            chosen.Clear()
            for row in picked:
                chosen.Add(row)
            if picked:
                self.sheets_lb.ScrollIntoView(picked[-1] if reveal_last else picked[0])
        finally:
            self._ready = True
        self.suggest_start()
        self.update()

    def suggest_start(self):
        """Boshlang'ich raqam maydoniga birinchi tanlangan list raqamini qo'yadi
        (foydalanuvchi o'zi yozgan bo'lsa tegilmaydi)."""
        if self._typed:
            return
        picked = self.board.picked(self.selected_keys())
        source = picked[0] if picked else (self.board.rows[0] if self.board.rows else None)
        self._ready = False
        try:
            self.start_tb.Text = source.number if source is not None else u''
        finally:
            self._ready = True

    def update(self):
        changes = self.board.changes()
        clashes = self.board.duplicates()
        self.status_tb.Text = (T('nm_status_n') % len(changes)) if changes else T('nm_status_none')
        if self._notice:
            self.warn_tb.Text = self._notice
        elif clashes:
            more = u', ...' if len(clashes) > 6 else u''
            self.warn_tb.Text = T('nm_status_dup') % (u', '.join(clashes[:6]) + more)
        else:
            self.warn_tb.Text = u''
        self.ok_btn.Content = (T('nm_save_n') % len(changes)) if changes else T('sv_save')
        self.ok_btn.IsEnabled = bool(changes) and not clashes

    def act(self, action, reveal_last=False):
        """Tanlangan listlar ustida amal bajaradi; hech narsa tanlanmagan bo'lsa eslatadi."""
        keys = self.selected_keys()
        if not keys:
            self._notice = T('nm_pick_first')
            self.update()
            return
        self._notice = action(keys) or u''
        self.redraw(keys, reveal_last)

    # --- hodisalar ---

    @safe
    def on_select(self, sender, args):
        if self._ready:
            self._notice = u''
            self.suggest_start()
            self.update()

    @safe
    def on_start_typed(self, sender, args):
        if self._ready:
            self._typed = True

    @safe
    def on_up(self, sender, args):
        self.act(lambda keys: self.board.move(keys, -1) and None)

    @safe
    def on_down(self, sender, args):
        self.act(lambda keys: self.board.move(keys, +1) and None, reveal_last=True)

    @safe
    def on_top(self, sender, args):
        self.act(lambda keys: self.board.move(keys, -1, far=True) and None)

    @safe
    def on_bottom(self, sender, args):
        self.act(lambda keys: self.board.move(keys, +1, far=True) and None, reveal_last=True)

    @safe
    def on_apply(self, sender, args):
        def renumber(keys):
            if not numerator.valid_number(self.start_tb.Text):
                return T('nm_bad_start')
            self.board.renumber(keys, self.start_tb.Text)
            self._typed = False             # keyingi tanlovda maydon yana o'zi to'ladi
            return None
        self.act(renumber)

    @safe
    def on_all(self, sender, args):
        self._notice = u''
        self.redraw([row.key for row in self.board.rows])

    @safe
    def on_reset(self, sender, args):
        keys = self.selected_keys()
        self.board.reset()
        self._notice = u''
        self._typed = False
        self.redraw(keys)

    @safe
    def on_ok(self, sender, args):
        if not self.board.changes() or self.board.duplicates():
            return
        self.accepted = True
        self.Close()

    @safe
    def on_cancel(self, sender, args):
        self.Close()


# --- ishga tushirish ---------------------------------------------------------

def main():
    doc, uidoc = revit.doc, revit.uidoc
    set_lang(catalog.load_settings().get('lang'))

    if doc.IsFamilyDocument:
        forms.alert(T('sh_family_doc'), title=APP)
        return
    rows, by_key = collect_sheets(doc)
    if not rows:
        forms.alert(T('nm_no_sheets'), title=APP)
        return
    board = numerator.Board(rows, T('nm_was'), T('nm_dup'))

    window = NumberWindow(board, selected_sheet_keys(doc, uidoc, by_key))
    window.show_dialog()
    if not window.accepted:
        return

    changes = board.changes()
    taken = [row.old for row in board.rows] + [row.number for row in board.rows]
    try:
        apply_numbers(doc, changes, by_key, taken)
    except Exception as err:
        forms.alert(T('nm_failed'), sub_msg=u'%s' % err, title=APP)
        return
    forms.alert(T('nm_done') % len(changes), title=APP, warn_icon=False)


main()
