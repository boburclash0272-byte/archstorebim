# -*- coding: utf-8 -*-
"""ArchStore BIM - Listlar.

Listlar yaratadi va belgilangan vidlarni ularga joylashtiradi: har bir vid
alohida listga yoki hammasi bitta listga. Ramka (shtamp) va birinchi list
raqami oynada tanlanadi."""

__title__ = 'Listlar'
__author__ = 'ArchStore BIM'

import clr

clr.AddReference('WindowsBase')
clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')

from pyrevit import DB, forms, revit

from archstore import catalog, sheets
from archstore.i18n import T, set_lang
from archstore.rvt import Tx
from archstore.ui import APP, ToolWindow, safe, vis


# --- loyihadan ma'lumot yig'ish ----------------------------------------------

def placed_view_ids(doc):
    """Allaqachon biror listda turgan vidlarning Id'lari."""
    found = set()
    for viewport in DB.FilteredElementCollector(doc).OfClass(DB.Viewport):
        found.add(viewport.ViewId)
    return found


def view_scale(view):
    try:
        return int(view.Scale)
    except Exception:
        return 0


def collect_views(doc):
    """(qatorlar, {UniqueId: vid}, yashirilgan vidlar soni).

    Listga qo'yish mumkin bo'lgan vidlar: shablon emas va hali listda turmagan.
    Legendani bir nechta listga qo'yish mumkin, shuning uchun u doim ko'rsatiladi."""
    on_sheets = placed_view_ids(doc)
    rows, by_key, hidden = [], {}, 0
    for view in DB.FilteredElementCollector(doc).OfClass(DB.View):
        try:
            if view.IsTemplate:
                continue
            kind = sheets.KIND_BY_VIEWTYPE.get(str(view.ViewType))
            if kind is None:
                continue
            if kind != 'legend' and view.Id in on_sheets:
                hidden += 1
                continue
            key = view.UniqueId
            rows.append(sheets.ViewRow(key, revit.query.get_name(view), kind, view_scale(view),
                                       T('sh_k_' + kind)))
            by_key[key] = view
        except Exception:
            continue
    return sheets.sort_rows(rows), by_key, hidden


def title_blocks(doc):
    """{'Oila : Tur': FamilySymbol} - loyihadagi ramka (shtamp) turlari."""
    found = {}
    symbols = (DB.FilteredElementCollector(doc)
               .OfCategory(DB.BuiltInCategory.OST_TitleBlocks)
               .WhereElementIsElementType())
    for symbol in symbols:
        try:
            name = u'%s : %s' % (symbol.FamilyName, revit.query.get_name(symbol))
        except Exception:
            name = revit.query.get_name(symbol)
        found[name] = symbol
    return found


def sheet_numbers(doc):
    return [sheet.SheetNumber for sheet in DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet)]


def check_selected(doc, uidoc, by_key):
    """Loyiha brauzerida tanlab qo'yilgan vidlar oldindan belgilanadi."""
    keys = set()
    try:
        for element_id in uidoc.Selection.GetElementIds():
            element = doc.GetElement(element_id)
            if isinstance(element, DB.View) and element.UniqueId in by_key:
                keys.add(element.UniqueId)
    except Exception:
        pass
    return keys


# --- list yaratish -----------------------------------------------------------

def build(doc, plan, by_key, names, frame):
    """Listlarni yaratadi va vidlarni joylashtiradi.

    Qaytaradi: (yaratilgan listlar, joylashtirilgan vidlar soni,
                [joylashmagan vid: sabab], [yaratilmagan list: sabab])."""
    created, placed, not_placed, failed = [], 0, [], []
    with Tx(doc, APP + u': listlar'):
        if frame is not None:
            frame_id = frame.Id
            if not frame.IsActive:
                frame.Activate()
                doc.Regenerate()
        else:
            frame_id = DB.ElementId.InvalidElementId
        for item in plan:
            step = DB.SubTransaction(doc)
            step.Start()
            try:
                sheet = DB.ViewSheet.Create(doc, frame_id)
                sheet.SheetNumber = item['number']
                name = sheets.clean_name(item['name'])
                if name:
                    try:
                        sheet.Name = name
                    except Exception:
                        pass                           # nom qabul qilinmadi - Revit bergan nom qoladi
                doc.Regenerate()
                outline = sheet.Outline
                box = sheets.sheet_box(outline.Min.U, outline.Min.V, outline.Max.U, outline.Max.V)
                centers = sheets.grid_centers(len(item['views']), box[0], box[1], box[2], box[3])
                count, problems = 0, []
                for key, center in zip(item['views'], centers):
                    view = by_key[key]
                    try:
                        if not DB.Viewport.CanAddViewToSheet(doc, sheet.Id, view.Id):
                            raise ValueError(T('sh_cannot'))
                        DB.Viewport.Create(doc, sheet.Id, view.Id, DB.XYZ(center[0], center[1], 0))
                        count += 1
                    except Exception as err:
                        problems.append(u'%s: %s' % (names[key], err))
                not_placed.extend(problems)
                if count:
                    step.Commit()
                    created.append(sheet)
                    placed += count
                else:
                    step.RollBack()                    # bo'sh list qoldirilmaydi
            except Exception as err:
                step.RollBack()
                failed.append(u'%s %s: %s' % (item['number'], item['name'], err))
    return created, placed, not_placed, failed


# --- oyna --------------------------------------------------------------------

class SheetWindow(ToolWindow):
    def __init__(self, rows, hidden, frame_names, taken, saved):
        ToolWindow.__init__(self)
        self.rows = rows
        self.taken = taken
        self.accepted = False
        self.plan = []
        self.frame_name = None
        self.mode = sheets.MODE_EACH
        self._ready = False

        self.title_tb.Text = T('sh_title')
        self.sub_tb.Text = T('sh_sub') % len(rows)
        self.hint_tb.Text = (T('sh_hidden') % hidden) if hidden else u''
        self.views_label.Text = T('sh_views')
        self.search_label.Text = T('sh_search')
        self.all_btn.Content = T('sh_check_all')
        self.clear_btn.Content = T('sh_clear')
        self.frame_label.Text = T('sh_frame')
        self.mode_label.Text = T('sh_mode')
        self.each_rb.Content = T('sh_each')
        self.one_rb.Content = T('sh_one')
        self.number_label.Text = T('sh_number')
        self.name_label.Text = T('sh_name')
        self.preview_label.Text = T('sh_preview')
        self.empty_tb.Text = T('sh_preview_empty')
        self.cancel_btn.Content = T('btn_cancel')

        # tur bo'yicha filtr: faqat loyihada bor turlar
        present = set(row.kind for row in rows)
        self.kinds = [None] + [kind for kind in sheets.KINDS if kind in present]
        self.kind_cb.ItemsSource = [T('sh_all_kinds')] + [T('sh_k_' + kind) for kind in self.kinds[1:]]
        self.kind_cb.SelectedIndex = 0

        # ramka: avvalgi tanlov eslab qolingan bo'lsa - o'sha, bo'lmasa birinchisi
        self.frames = frame_names + [None]
        self.frame_cb.ItemsSource = frame_names + [T('sh_no_frame')]
        remembered = saved.get('frame')
        if remembered in frame_names:
            self.frame_cb.SelectedIndex = frame_names.index(remembered)
        elif remembered == u'':                        # o'tgan safar "ramkasiz" tanlangan
            self.frame_cb.SelectedIndex = len(frame_names)
        else:
            self.frame_cb.SelectedIndex = 0

        if saved.get('mode') == sheets.MODE_ONE:
            self.one_rb.IsChecked = True
            self.each_rb.IsChecked = False
        self.number_tb.Text = sheets.suggest_start(taken)

        for row in rows:
            row._on_change = self.on_row_change

        self.search_tb.TextChanged += self.on_filter
        self.kind_cb.SelectionChanged += self.on_filter
        self.all_btn.Click += self.on_check_all
        self.clear_btn.Click += self.on_clear
        self.each_rb.Click += self.on_option
        self.one_rb.Click += self.on_option
        self.number_tb.TextChanged += self.on_option
        self.name_tb.TextChanged += self.on_option
        self.ok_btn.Click += self.on_ok
        self.cancel_btn.Click += self.on_cancel
        self._ready = True
        self.show_rows()
        self.update()

    # --- holat ---

    def current_mode(self):
        return sheets.MODE_ONE if self.one_rb.IsChecked else sheets.MODE_EACH

    def visible_rows(self):
        index = self.kind_cb.SelectedIndex
        kind = self.kinds[index] if 0 <= index < len(self.kinds) else None
        query = (self.search_tb.Text or u'').strip()
        return [row for row in self.rows if row.matches(kind, query)]

    def show_rows(self):
        self.views_lb.ItemsSource = self.visible_rows()

    def make_plan(self):
        return sheets.plan(self.current_mode(), self.rows, (self.number_tb.Text or u'').strip(),
                           self.name_tb.Text, self.taken)

    def update(self):
        one = self.current_mode() == sheets.MODE_ONE
        self.name_tb.IsEnabled = one
        self.note_tb.Text = u'%s %s' % (T('sh_number_note'), T('sh_name_one') if one else T('sh_name_each'))
        self.checked_tb.Text = T('sh_checked') % len([row for row in self.rows if row.checked])
        plan = self.make_plan()
        self.plan_lb.ItemsSource = [sheets.SheetLine(item['number'], sheets.clean_name(item['name']),
                                                     T('sh_views_n') % len(item['views']))
                                    for item in plan]
        self.empty_tb.Visibility = vis(not plan)
        self.ok_btn.Content = (T('fl_create_n') % len(plan)) if plan else T('fl_create')
        self.ok_btn.IsEnabled = bool(plan)

    # --- hodisalar ---

    def on_row_change(self):
        if self._ready:
            try:
                self.update()
            except Exception:
                pass

    @safe
    def on_filter(self, sender, args):
        if self._ready:
            self.show_rows()

    @safe
    def on_option(self, sender, args):
        if self._ready:
            self.update()

    def set_checked(self, rows, value):
        self._ready = False
        try:
            for row in rows:
                row.checked = value
        finally:
            self._ready = True
        self.show_rows()                               # belgilar qayta chiziladi
        self.update()

    @safe
    def on_check_all(self, sender, args):
        self.set_checked(self.visible_rows(), True)

    @safe
    def on_clear(self, sender, args):
        self.set_checked(self.rows, False)

    @safe
    def on_ok(self, sender, args):
        plan = self.make_plan()
        if not plan:
            return
        self.plan = plan
        self.mode = self.current_mode()
        index = self.frame_cb.SelectedIndex
        self.frame_name = self.frames[index] if 0 <= index < len(self.frames) else None
        self.accepted = True
        self.Close()

    @safe
    def on_cancel(self, sender, args):
        self.Close()


# --- ishga tushirish ---------------------------------------------------------

def main():
    doc, uidoc = revit.doc, revit.uidoc
    settings = catalog.load_settings()
    set_lang(settings.get('lang'))

    if doc.IsFamilyDocument:
        forms.alert(T('sh_family_doc'), title=APP)
        return
    rows, by_key, hidden = collect_views(doc)
    if not rows:
        forms.alert(T('sh_no_views'), title=APP)
        return
    for key in check_selected(doc, uidoc, by_key):
        for row in rows:
            if row.key == key:
                row._checked = True
    frames = title_blocks(doc)
    frame_names = sorted(frames, key=lambda n: n.lower())

    window = SheetWindow(rows, hidden, frame_names, sheet_numbers(doc), settings.get('sheets') or {})
    window.show_dialog()
    if not window.accepted:
        return

    names = dict((row.key, row.name) for row in rows)
    created, placed, not_placed, failed = build(doc, window.plan, by_key, names,
                                                frames.get(window.frame_name))

    settings = catalog.load_settings()
    settings['sheets'] = {'frame': window.frame_name or u'', 'mode': window.mode}
    catalog.save_settings(settings)

    lines = []
    if window.mode == sheets.MODE_ONE and placed > 1:
        lines.append(T('sh_arrange'))
    if not_placed:
        lines.append(T('sh_not_placed') % len(not_placed))
        lines.extend(u'   ' + text for text in not_placed)
    if failed:
        lines.append(T('sh_failed') % len(failed))
        lines.extend(u'   ' + text for text in failed)
    forms.alert(T('sh_done') % (len(created), placed), sub_msg=u'\n'.join(lines) or None, title=APP,
                warn_icon=bool(failed or not_placed))
    if created:
        try:
            uidoc.ActiveView = created[0]              # birinchi yangi list ochiladi
        except Exception:
            pass


main()
