# -*- coding: utf-8 -*-
"""Oynalar uchun umumiy yordamchilar (faqat Revit/pyRevit ichida import qilinadi)."""
import os
import traceback

import clr

clr.AddReference('WindowsBase')
clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')

from System.Windows import Visibility
from System.Windows.Media import ColorConverter, SolidColorBrush

from pyrevit import UI, forms, script

from archstore import catalog, styles, theme, updater
from archstore.i18n import T, get_lang

APP = u'ArchStore BIM'
WINDOW_VAR = 'ARCHSTOREBIM_WINDOW'    # ochiq Katalog oynasi shu nom bilan eslab qolinadi


def vis(flag):
    return Visibility.Visible if flag else Visibility.Collapsed


def hex_brush(value):
    brush = SolidColorBrush(ColorConverter.ConvertFromString(value))
    brush.Freeze()
    return brush


def revit_is_dark():
    """Revit hozir qorong'i mavzudami (Revit 2024+; eski versiyalarda doim yorug')."""
    try:
        return UI.UIThemeManager.CurrentTheme == UI.UITheme.Dark
    except Exception:
        return False


def apply_theme(window):
    """Sozlamalarda tanlangan mavzuni shu oynaga qo'llaydi."""
    name = theme.resolve(catalog.load_settings().get('theme'), revit_is_dark())
    for key, value in theme.THEMES[name].items():
        window.Resources[key] = hex_brush(value)
    return name


def report(text):
    try:
        forms.alert(T('err_unexpected'), sub_msg=text, title=APP)
    except Exception:
        pass


def safe(handler):
    """Oyna hodisalaridagi xatolarni ushlab, matnini ko'rsatadi."""
    def wrapper(self, *args):
        try:
            return handler(self, *args)
        except Exception:
            report(traceback.format_exc())
    return wrapper


class ToolWindow(forms.WPFWindow):
    """Hamma asbob oynalari uchun asos.

    - ui.xaml ga umumiy uslublarni (styles.xamlpart) qo'shib yuklaydi;
    - Sozlamalarda tanlangan mavzuni (yorug' / qorong'i / Revit kabi) qo'llaydi va
      oynaga qaytilganda qayta tekshiradi.

    Yangi asbob:  class MyWindow(ToolWindow): def __init__(self): ToolWindow.__init__(self)
    """

    def __init__(self, xaml_name='ui.xaml', handle_esc=True):
        forms.WPFWindow.__init__(self, styles.compose(script.get_bundle_file(xaml_name)),
                                 handle_esc=handle_esc)
        self.theme_name = apply_theme(self)
        self.Activated += self._on_activated

    def _on_activated(self, sender, args):
        try:
            self.theme_name = apply_theme(self)
        except Exception:
            pass


# --- yangilanish --------------------------------------------------------------

_UPDATE_ERRORS = {'network': 'up_err_network', 'not_configured': 'up_err_not_configured',
                  'insecure': 'up_err_insecure', 'checksum': 'up_err_checksum',
                  'write': 'up_err_write'}


def update_error_text(error):
    return T(_UPDATE_ERRORS.get(error.key, 'up_err_package'))


def reload_pyrevit():
    """Yangi fayllar kuchga kirishi uchun pyRevit'ni qayta yuklaydi."""
    try:
        window = script.get_envvar(WINDOW_VAR)
        if window is not None:
            window.Close()
    except Exception:
        pass
    try:
        from pyrevit.loader import sessionmgr
        sessionmgr.reload_pyrevit()
    except Exception:
        forms.alert(T('up_reload'), title=APP)


def run_update_flow(quiet_if_latest=False):
    """Tekshiradi -> so'raydi -> o'rnatadi -> pyRevit'ni qayta yuklaydi.
    Yangilanish o'rnatilgan bo'lsa True qaytaradi."""
    try:
        update = updater.check()
    except updater.UpdateError as error:
        forms.alert(update_error_text(error), title=APP)
        return False
    except Exception:
        report(traceback.format_exc())
        return False
    if update is None:
        if not quiet_if_latest:
            forms.alert(T('up_latest') % updater.read_local()['version'], title=APP, warn_icon=False)
        return False
    agreed = forms.alert(T('up_found') % (update.version, update.current),
                         sub_msg=update.note(get_lang()) or None, title=APP,
                         ok=False, yes=True, no=True, warn_icon=False)
    if not agreed:
        return False
    try:
        version = updater.install(update, backup_dir=os.path.join(catalog.data_dir(), 'backup'))
    except updater.UpdateError as error:
        forms.alert(update_error_text(error), sub_msg=error.detail or None, title=APP)
        return False
    except Exception:
        report(traceback.format_exc())
        return False
    settings = catalog.load_settings()
    settings.pop('update_version', None)
    catalog.save_settings(settings)
    forms.alert(T('up_done') % version, title=APP, warn_icon=False)
    reload_pyrevit()
    return True
