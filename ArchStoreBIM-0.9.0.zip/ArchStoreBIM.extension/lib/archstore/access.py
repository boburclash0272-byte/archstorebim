# -*- coding: utf-8 -*-
"""Modelga kirish huquqi.

Prototipda hamma model ochiq. Pullik bosqichda obuna tekshiruvi
(serverga so'rov) aynan shu funksiyaga qo'yiladi - plaginning
qolgan qismi o'zgarmaydi.
"""


def can_use(item):
    return True
