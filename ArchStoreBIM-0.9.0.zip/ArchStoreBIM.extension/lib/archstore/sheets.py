# -*- coding: utf-8 -*-
""""Listlar" asbobining Revit'ga bog'liq bo'lmagan qismi: vid qatorlari, list
raqamlari, yaratiladigan listlar rejasi va vidlarni list ustida joylashtirish."""

# vid turlari: kalit -> i18n kaliti; tartib ro'yxatdagi tartibni belgilaydi
KINDS = ('plan', 'ceiling', 'section', 'elevation', '3d', 'drafting', 'legend')
MODE_EACH = 'each'      # har bir vid alohida listga
MODE_ONE = 'one'        # hamma vid bitta listga

# Revit'dagi vid turi (ViewType nomi) -> bizdagi tur. Bu ro'yxatda yo'q vidlar
# (spetsifikatsiya, list, brauzer va h.k.) listga qo'yish uchun taklif qilinmaydi.
KIND_BY_VIEWTYPE = {
    'FloorPlan': 'plan', 'EngineeringPlan': 'plan', 'AreaPlan': 'plan',
    'CeilingPlan': 'ceiling',
    'Section': 'section', 'Detail': 'section',
    'Elevation': 'elevation',
    'ThreeD': '3d', 'Rendering': '3d',
    'DraftingView': 'drafting',
    'Legend': 'legend',
}

# Revit list nomida shu belgilarga ruxsat bermaydi (masalan standart "{3D}" vidi nomidagi qavslar)
BAD_NAME_CHARS = u'\\:{}[]|;<>?`~'
# ramkasiz list uchun joylash maydoni: A3 (420 x 297 mm), fut hisobida
DEFAULT_SHEET = (0.0, 0.0, 420.0 / 304.8, 297.0 / 304.8)


class ViewRow(object):
    """Oynadagi bitta vid qatori (XAML shu maydonlarga bog'lanadi)."""

    def __init__(self, key, name, kind, scale, kind_label, on_change=None):
        self.key = key
        self.name = name or u''
        self.kind = kind
        self.kind_label = kind_label
        self.scale_text = (u'1:%d' % scale) if scale and scale > 0 else u''
        self._checked = False
        self._on_change = on_change

    @property
    def checked(self):
        return self._checked

    @checked.setter
    def checked(self, value):
        self._checked = bool(value)
        if self._on_change:
            self._on_change()

    def matches(self, kind, query):
        if kind and self.kind != kind:
            return False
        if not query:
            return True
        hay = (self.name + u' ' + self.kind_label).lower()
        return all(word in hay for word in query.lower().split())


class SheetLine(object):
    """"Yaratiladigan listlar" ro'yxatidagi bitta qator."""

    def __init__(self, number, name, info):
        self.number = number
        self.name = name
        self.info = info


def clean_name(text):
    """List nomi: Revit qabul qilmaydigan belgilar olib tashlanadi."""
    text = u''.join(ch for ch in (text or u'') if ch not in BAD_NAME_CHARS and ch >= u' ')
    return u' '.join(text.split())


def sort_rows(rows):
    order = dict((k, i) for i, k in enumerate(KINDS))
    return sorted(rows, key=lambda r: (order.get(r.kind, 99), natural_key(r.name)))


def natural_key(text):
    """'Plan 2' < 'Plan 10' bo'lishi uchun: matn va sonlarni ajratib saralaydi."""
    parts, digits, chars = [], u'', u''
    for ch in (text or u'').lower():
        if ch.isdigit():
            if chars:
                parts.append((1, 0, chars))
                chars = u''
            digits += ch
        else:
            if digits:
                parts.append((0, int(digits), u''))
                digits = u''
            chars += ch
    if digits:
        parts.append((0, int(digits), u''))
    if chars:
        parts.append((1, 0, chars))
    return parts


# --- list raqamlari -----------------------------------------------------------

def split_number(text):
    """'A-07' -> ('A-', 7, 2): old qism, oxirgi son, sonning uzunligi. Son bo'lmasa (matn, None, 0)."""
    text = (text or u'').strip()
    digits = u''
    for ch in reversed(text):
        if ch.isdigit():
            digits = ch + digits
        else:
            break
    if not digits:
        return text, None, 0
    return text[:len(text) - len(digits)], int(digits), len(digits)


def next_numbers(start, count, taken=()):
    """Boshlang'ich raqamdan boshlab `count` ta bo'sh raqam: 'A-01' -> A-01, A-02, ...
    Loyihada band bo'lgan (taken) raqamlar o'tkazib yuboriladi."""
    prefix, number, width = split_number(start)
    if number is None:
        number, width = 1, 1
        first = None                 # 'AR' -> AR1, AR2, ...
    else:
        first = number
    busy = set(t.strip().lower() for t in taken)
    result = []
    current = first if first is not None else number
    while len(result) < count:
        text = u'%s%s' % (prefix, (u'%d' % current).zfill(width))
        if text.lower() not in busy:
            result.append(text)
            busy.add(text.lower())
        current += 1
    return result


def suggest_start(existing):
    """Loyihadagi oxirgi list raqamidan keyingisini taklif qiladi; listlar bo'lmasa '1'."""
    best = None
    for text in existing:
        prefix, number, width = split_number(text)
        if number is None:
            continue
        rank = (natural_key(prefix), number)
        if best is None or rank > best[0]:
            best = (rank, prefix, number, width)
    if best is None:
        return u'1'
    return next_numbers(u'%s%s' % (best[1], (u'%d' % (best[2] + 1)).zfill(best[3])), 1, existing)[0]


# --- reja ---------------------------------------------------------------------

def plan(mode, rows, start, single_name, taken=()):
    """Yaratiladigan listlar: [{'number': ..., 'name': ..., 'views': [vid kalitlari]}, ...]"""
    picked = [r for r in rows if r.checked]
    if not picked:
        return []
    if mode == MODE_ONE:
        number = next_numbers(start, 1, taken)[0]
        name = (single_name or u'').strip() or picked[0].name
        return [{'number': number, 'name': name, 'views': [r.key for r in picked]}]
    numbers = next_numbers(start, len(picked), taken)
    return [{'number': n, 'name': r.name, 'views': [r.key]} for n, r in zip(numbers, picked)]


def sheet_box(min_u, min_v, max_u, max_v):
    """List chegarasi; ramkasiz list chegarasi bo'sh keladi - unda A3 maydoni olinadi."""
    if max_u - min_u < 0.2 or max_v - min_v < 0.2:
        return DEFAULT_SHEET
    return min_u, min_v, max_u, max_v


def grid_centers(count, min_u, min_v, max_u, max_v, margin=0.07):
    """List maydonida `count` ta vid markazi: qator-ustun bo'yicha, chapdan o'ngga, tepadan pastga.
    Bitta vid - maydon markazi."""
    if count <= 0:
        return []
    width, height = max_u - min_u, max_v - min_v
    left, bottom = min_u + width * margin, min_v + height * margin
    width, height = width * (1 - 2 * margin), height * (1 - 2 * margin)
    cols = 1
    while cols * cols < count:
        cols += 1
    rows = (count + cols - 1) // cols
    centers = []
    for i in range(count):
        col, row = i % cols, i // cols
        centers.append((left + width * (col + 0.5) / cols,
                        bottom + height * (rows - row - 0.5) / rows))
    return centers
