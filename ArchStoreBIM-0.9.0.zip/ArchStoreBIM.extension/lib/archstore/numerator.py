# -*- coding: utf-8 -*-
""""Nomerator" asbobining Revit'ga bog'liq bo'lmagan qismi.

G'oya: raqam ro'yxatdagi O'RINGA tegishli. List tepaga yoki pastga surilsa, u
o'sha o'rindagi raqamni oladi (qo'shnisi bilan raqam almashadi). Tanlangan
listlarga boshlang'ich raqamdan boshlab ketma-ket raqam berish ham mumkin."""
from archstore import sheets


class SheetRow(object):
    """Oynadagi bitta list qatori (XAML shu maydonlarga bog'lanadi)."""

    def __init__(self, key, number, name):
        self.key = key
        self.old = (number or u'')          # loyihadagi hozirgi raqam
        self.name = name or u''
        self.number = self.old              # yangi raqam
        self.old_text = u''                 # 'avval: A-03' - raqam o'zgargan bo'lsa
        self.warn = u''                     # takror raqam belgisi

    @property
    def changed(self):
        return self.number != self.old


def _same(text):
    return (text or u'').strip().lower()


def valid_number(text):
    """List raqami sifatida yaroqlimi: bo'sh emas va Revit taqiqlagan belgilar yo'q."""
    text = (text or u'').strip()
    return bool(text) and sheets.clean_name(text) == u' '.join(text.split())


class Board(object):
    """Listlar ro'yxati va ularning yangi raqamlari."""

    def __init__(self, rows, was_format=u'%s', duplicate_text=u'!'):
        self.rows = sorted(rows, key=lambda r: sheets.natural_key(r.old))
        self.was_format = was_format
        self.duplicate_text = duplicate_text
        self._sync()

    # --- holat ---

    def _sync(self):
        counts = {}
        for row in self.rows:
            counts[_same(row.number)] = counts.get(_same(row.number), 0) + 1
        for row in self.rows:
            row.old_text = (self.was_format % row.old) if row.changed else u''
            row.warn = self.duplicate_text if counts[_same(row.number)] > 1 else u''

    def duplicates(self):
        """Takrorlangan yangi raqamlar (ro'yxat tartibida, bittadan)."""
        seen, result = set(), []
        for row in self.rows:
            if row.warn and _same(row.number) not in seen:
                seen.add(_same(row.number))
                result.append(row.number)
        return result

    def changes(self):
        """[(kalit, eski raqam, yangi raqam)] - faqat o'zgarganlari."""
        return [(row.key, row.old, row.number) for row in self.rows if row.changed]

    def picked(self, keys):
        keys = set(keys)
        return [row for row in self.rows if row.key in keys]

    # --- amallar ---

    def _step(self, keys, delta):
        count, moved = len(self.rows), False
        order = range(count) if delta < 0 else range(count - 1, -1, -1)
        for i in order:
            j = i + delta
            if self.rows[i].key in keys and 0 <= j < count and self.rows[j].key not in keys:
                self.rows[i], self.rows[j] = self.rows[j], self.rows[i]
                moved = True
        return moved

    def move(self, keys, delta, far=False):
        """Tanlangan listlarni bir qadam tepaga (delta=-1) yoki pastga (+1) suradi;
        far=True - eng tepaga / eng pastga. Raqamlar o'rinda qoladi. Surildimi - qaytaradi."""
        keys = set(keys)
        numbers = [row.number for row in self.rows]
        moved = False
        while self._step(keys, delta):
            moved = True
            if not far:
                break
        for row, number in zip(self.rows, numbers):
            row.number = number
        self._sync()
        return moved

    def renumber(self, keys, start):
        """Tanlangan listlarga ro'yxat tartibida ketma-ket raqam beradi: A-01, A-02, ...
        Boshlang'ich raqam yaroqsiz bo'lsa False qaytaradi va hech narsa o'zgarmaydi."""
        if not valid_number(start):
            return False
        rows = self.picked(keys)
        for row, number in zip(rows, sheets.next_numbers(start.strip(), len(rows))):
            row.number = number
        self._sync()
        return bool(rows)

    def reset(self):
        for row in self.rows:
            row.number = row.old
        self.rows.sort(key=lambda r: sheets.natural_key(r.old))
        self._sync()


def temp_numbers(count, taken):
    """Vaqtincha raqamlar: listlar raqam almashganda bir lahza ham takror bo'lmasligi uchun."""
    busy = set(_same(t) for t in taken)
    result, n = [], 0
    while len(result) < count:
        n += 1
        text = u'TMP-ASB-%d' % n
        if _same(text) not in busy:
            result.append(text)
    return result
