# -*- coding: utf-8 -*-
"""Avtosaqlash sozlamalari va vaqt hisobi (Revit'ga bog'liq emas).

Sozlamalar umumiy settings.json ichida:
    "autosave": {"enabled": true, "minutes": 30}
    "autosave_last": {"at": "2026-10-08 15:42", "saved": 2, "unsaved": [...], "error": ""}
"""

TEST = 0.5                  # 30 soniya - faqat ishlashini tekshirish uchun
OPTIONS = (TEST, 15, 30, 60)    # daqiqa
DEFAULT = 30


def read(settings):
    """{'enabled': bool, 'minutes': 0.5 | 15 | 30 | 60} - noto'g'ri qiymatlar tuzatiladi."""
    raw = settings.get('autosave')
    if not isinstance(raw, dict):
        raw = {}
    minutes = raw.get('minutes')
    if minutes not in OPTIONS:
        minutes = DEFAULT
    return {'enabled': raw.get('enabled') is True, 'minutes': minutes}


def write(settings, enabled=None, minutes=None):
    """Sozlamani o'zgartiradi (None - tegilmaydi) va settings'ni qaytaradi."""
    current = read(settings)
    if enabled is not None:
        current['enabled'] = bool(enabled)
    if minutes in OPTIONS:
        current['minutes'] = minutes
    settings['autosave'] = current
    return settings


def due(now, last, minutes):
    """Oxirgi saqlashdan beri belgilangan vaqt o'tdimi (now, last - soniyalarda)."""
    return (now - last) >= minutes * 60


def remaining_minutes(now, last, minutes):
    """Keyingi saqlashgacha qolgan daqiqalar (kamida 0, yuqoriga yaxlitlanadi)."""
    left = minutes * 60 - (now - last)
    if left <= 0:
        return 0
    return int((left + 59) // 60)


def record(settings, at, saved, unsaved, error):
    """Oxirgi avtosaqlash natijasini yozib qo'yadi (oyna shuni ko'rsatadi)."""
    settings['autosave_last'] = {'at': at, 'saved': saved, 'unsaved': list(unsaved)[:5],
                                 'error': error or u''}
    return settings


def last(settings):
    raw = settings.get('autosave_last')
    return raw if isinstance(raw, dict) and raw.get('at') else None
