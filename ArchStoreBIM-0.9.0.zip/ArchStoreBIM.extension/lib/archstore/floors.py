# -*- coding: utf-8 -*-
""""Pol" asbobining Revit'ga bog'liq bo'lmagan qismi: xona qatorlari, eshik
o'rnidagi to'rtburchak, preview masshtabi va pol turini eslab qolish.

Koordinatalar Revit ichki birligida (fut), (x, y) juftliklari ko'rinishida.
"""

FT2_TO_M2 = 0.09290304
MM_PER_FT = 304.8
OVERLAP = 0.01          # eshik to'rtburchagi xona ichiga shuncha kiradi (fut, ~3 mm) - birlashishi uchun

# preview'da pol turlari shu ranglar bilan ajratiladi (tartib bilan)
TYPE_COLORS = ('#C9D8B6', '#C5D4E8', '#E3CDB8', '#D9C8E6', '#F0DFA8', '#BFDCD6', '#E8C4C4', '#D2D2D2')
NO_TYPE_COLOR = '#E4E2DC'
OPENING_COLOR = '#D64545'


class RoomRow(object):
    """Oynadagi bitta xona qatori (XAML shu maydonlarga bog'lanadi)."""

    def __init__(self, key, number, name, area_ft2, loops, label, none_label, on_change=None):
        self.key = key                      # xonaning Revit'dagi UniqueId'si
        self.number = number or u''
        self.name = name or u''
        self.title = (u'%s · %s' % (self.number, self.name)).strip(u' ·')
        self.area_text = u'%.1f m²' % (area_ft2 * FT2_TO_M2)
        self.loops = loops                  # [[(x, y), ...], ...] - birinchisi tashqi kontur
        self.label = label                  # (x, y) - xona nomi yoziladigan nuqta
        self.openings = []                  # [[(x, y) * 4], ...] - eshik o'rinlari
        self.types = []                     # tanlov ro'yxati: [none_label, tur1, tur2, ...]
        self._none = none_label
        self._checked = True
        self._type = u''
        self._on_change = on_change

    def _changed(self):
        if self._on_change:
            self._on_change()

    @property
    def checked(self):
        return self._checked

    @checked.setter
    def checked(self, value):
        self._checked = bool(value)
        self._changed()

    @property
    def type_item(self):
        """Ro'yxatda tanlangan element (tur nomi yoki 'tanlanmagan')."""
        return self._type or self._none

    @type_item.setter
    def type_item(self, value):
        self._type = u'' if (not value or value == self._none) else value
        self._changed()

    @property
    def type_name(self):
        return self._type

    @property
    def ready(self):
        """Bu xonaga pol yaratiladimi: belgilangan va turi tanlangan."""
        return self._checked and bool(self._type)


def opening_rect(center, direction, width, wall_width, side, overlap=OVERLAP):
    """Eshik o'rnidagi pol bo'lagi: devor o'qidan xona tomondagi yuzagacha.

    center    - eshik markazi devor o'qida (x, y)
    direction - devor yo'nalishi, birlik vektor (dx, dy)
    width     - eshik eni; wall_width - devor qalinligi
    side      - xona devor o'qining qaysi tomonida: +1 yoki -1 (normal bo'yicha)
    To'rtburchakning to'rt burchagini qaytaradi; xona ichiga `overlap` qadar kiradi.
    """
    cx, cy = center
    dx, dy = direction
    nx, ny = -dy * side, dx * side
    half = width / 2.0
    depth = wall_width / 2.0 + overlap
    a = (cx - dx * half, cy - dy * half)
    b = (cx + dx * half, cy + dy * half)
    return [a, b, (b[0] + nx * depth, b[1] + ny * depth), (a[0] + nx * depth, a[1] + ny * depth)]


def bounds(rows):
    """Hamma xonalarni o'rab turgan to'rtburchak: (minx, miny, maxx, maxy) yoki None."""
    xs, ys = [], []
    for row in rows:
        for loop in row.loops:
            for x, y in loop:
                xs.append(x)
                ys.append(y)
    if not xs:
        return None
    return min(xs), min(ys), max(xs), max(ys)


def fit(box, width, height, pad=14.0):
    """Reja (fut) -> rasm (piksel) o'tkazish: (masshtab, x siljish, y siljish).

    Reja maydon markaziga joylashadi; y o'qi teskari (ekranda pastga o'sadi).
    """
    minx, miny, maxx, maxy = box
    span_x = max(maxx - minx, 1e-6)
    span_y = max(maxy - miny, 1e-6)
    scale = min((width - 2 * pad) / span_x, (height - 2 * pad) / span_y)
    scale = max(scale, 1e-6)
    ox = (width - span_x * scale) / 2.0 - minx * scale
    oy = (height + span_y * scale) / 2.0 + miny * scale
    return scale, ox, oy


def to_canvas(point, transform):
    scale, ox, oy = transform
    return point[0] * scale + ox, oy - point[1] * scale


def type_colors(rows):
    """{tur nomi: rang} - tanlangan turlarga nom tartibida rang beradi."""
    names = sorted(set(r.type_name for r in rows if r.type_name), key=lambda n: n.lower())
    return dict((n, TYPE_COLORS[i % len(TYPE_COLORS)]) for i, n in enumerate(names))


def parse_offset(text):
    """'20', '-15,5', ' 0 ' -> mm (float); noto'g'ri matn -> None."""
    text = (text or u'').strip().replace(u',', u'.').replace(u' ', u'')
    if not text:
        return 0.0
    try:
        value = float(text)
    except ValueError:
        return None
    if value != value or abs(value) > 100000:
        return None
    return value


# --- pol turini xona nomi bo'yicha eslab qolish -------------------------------

def _name_key(name):
    return (name or u'').strip().lower()


def apply_remembered(rows, settings, available):
    """Avval tanlangan turlarni qaytaradi (tur loyihada hali bor bo'lsa)."""
    saved = settings.get('floor_types') or {}
    have = set(available)
    for row in rows:
        name = saved.get(_name_key(row.name))
        if name in have:
            row._type = name


def remember(rows, settings):
    saved = dict(settings.get('floor_types') or {})
    for row in rows:
        if row.type_name and _name_key(row.name):
            saved[_name_key(row.name)] = row.type_name
    settings['floor_types'] = saved
    return settings


# --- kontur bilan ishlash -------------------------------------------------------

def polygon_area(points):
    """Ko'pburchak yuzasi (ishorasiz)."""
    total = 0.0
    n = len(points)
    for i in range(n):
        x1, y1 = points[i]
        x2, y2 = points[(i + 1) % n]
        total += x1 * y2 - x2 * y1
    return abs(total) / 2.0


def centroid(points):
    n = float(len(points))
    return sum(p[0] for p in points) / n, sum(p[1] for p in points) / n


def dedupe(points, tolerance=0.005):
    """Ketma-ket juda yaqin nuqtalarni olib tashlaydi (Revit juda qisqa chiziqni qabul qilmaydi)."""
    out = []
    for p in points:
        if not out or abs(p[0] - out[-1][0]) > tolerance or abs(p[1] - out[-1][1]) > tolerance:
            out.append(p)
    while len(out) > 1 and abs(out[0][0] - out[-1][0]) <= tolerance and abs(out[0][1] - out[-1][1]) <= tolerance:
        out.pop()
    return out


def number_key(text):
    """Xona raqami bo'yicha saralash: '2' < '10' < '10a' < 'A1'."""
    digits = u''
    for ch in (text or u''):
        if ch.isdigit():
            digits += ch
        else:
            break
    return (0, int(digits), text) if digits else (1, 0, text or u'')
