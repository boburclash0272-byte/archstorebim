# -*- coding: utf-8 -*-
""""Saqlash" asbobining Revit'ga bog'liq bo'lmagan qismi: loyiha papkalari
tuzilmasi va fayl nomini tekshirish.

Tuzilmani o'zgartirish kerak bo'lsa - faqat shu fayldagi FOLDERS va WORK."""
import os

# loyiha papkasi ichida yaratiladigan papkalar (tartib bilan)
FOLDERS = (
    u'010_Общие',
    u'020_Исходные данные',
    u'021_Библиотеки',
    u'022_Шаблоны',
    u'023_ТУ',
    u'030_В работе',
    u'040_Общий доступ',
    u'050_Опубликовано',
    u'060_Архив',
)
WORK = u'030_В работе'          # Revit fayli shu papkaga saqlanadi
EXTENSION = u'.rvt'

BAD_CHARS = u'\\/:*?"<>|'
_RESERVED = set([u'con', u'prn', u'aux', u'nul'] + [u'com%d' % i for i in range(1, 10)]
                + [u'lpt%d' % i for i in range(1, 10)])


class FolderLine(object):
    """Oynadagi papkalar ro'yxatining bitta qatori."""

    def __init__(self, name, note, file_name):
        self.name = name
        self.note = note                # 'bor' / 'yaratiladi'
        self.file_name = file_name      # faqat ish papkasida: saqlanadigan fayl nomi


def clean_file_name(text):
    """Foydalanuvchi yozgan nom -> fayl nomi (kengaytmasiz).
    Bo'sh bo'lsa u'' , yaroqsiz bo'lsa None qaytaradi."""
    name = (text or u'').strip()
    if name.lower().endswith(EXTENSION):
        name = name[:-len(EXTENSION)].strip()
    name = name.rstrip(u'. ')
    if not name:
        return u''
    for ch in name:
        if ch in BAD_CHARS or ch < u' ':
            return None
    if name.lower() in _RESERVED:
        return None
    return name


def clean_root(text):
    """Papka yo'li: bo'sh joy va qo'shtirnoqlar olib tashlanadi."""
    return (text or u'').strip().strip(u'"').strip()


def target_path(root, name):
    return os.path.join(root, WORK, name + EXTENSION)


def missing(root):
    """Loyiha papkasida hali yo'q papkalar."""
    return [name for name in FOLDERS if not os.path.isdir(os.path.join(root, name))]


def create(root):
    """Yo'q papkalarni yaratadi (borlariga tegmaydi). Yaratilganlar ro'yxatini qaytaradi."""
    made = []
    for name in missing(root):
        os.mkdir(os.path.join(root, name))
        made.append(name)
    return made


def lines(root, name, exists_text, new_text):
    """Oynadagi ro'yxat: har bir papka, holati va ish papkasida - fayl nomi."""
    absent = set(missing(root)) if root and os.path.isdir(root) else set(FOLDERS)
    result = []
    for folder in FOLDERS:
        file_name = (name + EXTENSION) if (folder == WORK and name) else u''
        result.append(FolderLine(folder, new_text if folder in absent else exists_text, file_name))
    return result
