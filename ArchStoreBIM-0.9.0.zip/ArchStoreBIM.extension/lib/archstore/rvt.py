# -*- coding: utf-8 -*-
"""Revit bilan ishlashda hamma asboblarga kerak bo'ladigan yordamchilar
(faqat Revit/pyRevit ichida import qilinadi)."""
from pyrevit import DB


class Tx(object):
    """with Tx(doc, nom): ...  - xato bo'lsa o'zgarishlar bekor qilinadi."""

    def __init__(self, doc, name):
        self.tx = DB.Transaction(doc, name)

    def __enter__(self):
        self.tx.Start()
        return self

    def __exit__(self, kind, value, trace):
        if kind is None:
            self.tx.Commit()
        elif self.tx.HasStarted() and not self.tx.HasEnded():
            self.tx.RollBack()
        return False
