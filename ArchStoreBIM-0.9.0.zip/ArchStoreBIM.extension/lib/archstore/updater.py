# -*- coding: utf-8 -*-
"""Plaginni yangilash.

Qanday ishlaydi:
  1. Kengaytma ildizidagi version.json - o'rnatilgan versiya va yangilanish manzili:
         {"version": "0.5.0", "update_url": "https://.../version.json"}
  2. Shu manzildagi version.json (reliz manifesti):
         {"version": "0.6.0", "url": "ArchStoreBIM-0.6.0.zip",
          "sha256": "...", "notes": {"uz": "...", "ru": "...", "en": "..."}}
     "url" to'liq yoki manifest yonidagi fayl nomi bo'lishi mumkin.
  3. Versiya yangi bo'lsa: zip yuklanadi, sha256 tekshiriladi, vaqtinchalik
     papkaga ochiladi, joriy versiya zaxiraga olinadi va fayllar almashtiriladi.

Modul Revit'ga bog'liq emas; tarmoq IronPython'da .NET orqali (TLS 1.2), oddiy
Python'da urllib orqali ishlaydi.
"""
import hashlib
import io
import json
import os
import shutil
import sys
import tempfile
import zipfile

IS_CLI = sys.platform == 'cli'
VERSION_FILE = 'version.json'
MAX_BYTES = 300 * 1024 * 1024
KEEP_BACKUPS = 3
_TEXT = type(u'')


class UpdateError(Exception):
    """key - i18n kaliti uchun qisqa sabab nomi (masalan 'network', 'checksum')."""

    def __init__(self, key, detail=u''):
        Exception.__init__(self, u'%s: %s' % (key, detail))
        self.key = key
        self.detail = detail


# --- versiyalar ---------------------------------------------------------------

def parse_version(text):
    """'0.5.0' -> (0, 5, 0); noto'g'ri matn -> ()"""
    parts = []
    for piece in (text or u'').strip().lstrip('vV').split('.'):
        digits = u''
        for ch in piece:
            if ch.isdigit():
                digits += ch
            else:
                break
        if not digits:
            return ()
        parts.append(int(digits))
    return tuple(parts)


def is_newer(candidate, current):
    a, b = parse_version(candidate), parse_version(current)
    if not a:
        return False
    size = max(len(a), len(b))
    return a + (0,) * (size - len(a)) > b + (0,) * (size - len(b))


def extension_dir():
    """Kengaytma ildizi: .../ArchStoreBIM.extension (bu fayl lib/archstore ichida)."""
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(os.path.dirname(here))


def read_local(ext_dir=None):
    """O'rnatilgan versiya haqida: {'version': ..., 'update_url': ...}"""
    path = os.path.join(ext_dir or extension_dir(), VERSION_FILE)
    try:
        with io.open(path, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    return {'version': data.get('version') or u'0', 'update_url': (data.get('update_url') or u'').strip()}


# --- tarmoq -------------------------------------------------------------------

def allowed(url):
    """Faqat https; http faqat shu kompyuterning o'zi uchun (sinov)."""
    low = (url or u'').lower()
    return (low.startswith('https://') or low.startswith('http://127.0.0.1')
            or low.startswith('http://localhost'))


def _request(url, timeout):
    from System.Net import SecurityProtocolType, ServicePointManager, WebRequest
    try:
        ServicePointManager.SecurityProtocol = (ServicePointManager.SecurityProtocol
                                                | SecurityProtocolType.Tls12)
    except Exception:
        pass
    request = WebRequest.Create(url)
    request.Timeout = int(timeout * 1000)
    try:
        request.ReadWriteTimeout = int(timeout * 1000)
        request.UserAgent = 'ArchStoreBIM-Updater'
    except Exception:
        pass
    return request.GetResponse()


def fetch_text(url, timeout=6):
    if not allowed(url):
        raise UpdateError('insecure', url)
    try:
        if IS_CLI:
            from System.IO import StreamReader
            from System.Text import Encoding
            response = _request(url, timeout)
            try:
                return StreamReader(response.GetResponseStream(), Encoding.UTF8).ReadToEnd()
            finally:
                response.Close()
        from urllib.request import urlopen
        return urlopen(url, timeout=timeout).read().decode('utf-8')
    except UpdateError:
        raise
    except Exception as err:
        raise UpdateError('network', u'%s' % err)


def fetch_file(url, target, timeout=30):
    if not allowed(url):
        raise UpdateError('insecure', url)
    try:
        if IS_CLI:
            from System.IO import File
            response = _request(url, timeout)
            try:
                if response.ContentLength > MAX_BYTES:
                    raise UpdateError('too_big', u'%s' % response.ContentLength)
                output = File.Create(target)
                try:
                    response.GetResponseStream().CopyTo(output)
                finally:
                    output.Close()
            finally:
                response.Close()
        else:
            from urllib.request import urlopen
            data = urlopen(url, timeout=timeout).read(MAX_BYTES + 1)
            with open(target, 'wb') as f:
                f.write(data)
        if os.path.getsize(target) > MAX_BYTES:
            raise UpdateError('too_big', u'%s' % os.path.getsize(target))
    except UpdateError:
        raise
    except Exception as err:
        raise UpdateError('network', u'%s' % err)


# --- tekshirish ---------------------------------------------------------------

class Update(object):
    def __init__(self, version, url, sha256, notes, current):
        self.version = version
        self.url = url
        self.sha256 = (sha256 or u'').strip().lower()
        self.notes = notes
        self.current = current

    def note(self, lang):
        """Shu tildagi izoh; bo'lmasa inglizcha yoki birinchi uchragani."""
        notes = self.notes
        if isinstance(notes, dict):
            for key in (lang, 'en', 'uz', 'ru'):
                if notes.get(key):
                    return notes[key]
            return u''
        return notes or u''


def _join(base_url, name):
    low = name.lower()
    if low.startswith('http://') or low.startswith('https://'):
        return name
    return base_url.rsplit('/', 1)[0] + '/' + name.lstrip('/')


def check(ext_dir=None, fetch=fetch_text):
    """Yangi versiya bo'lsa Update, bo'lmasa None qaytaradi."""
    local = read_local(ext_dir)
    if not local['update_url']:
        raise UpdateError('not_configured')
    text = fetch(local['update_url'])
    try:
        manifest = json.loads(text.lstrip(u'﻿'))
        version = manifest['version']
        url = _join(local['update_url'], manifest['url'])
    except Exception as err:
        raise UpdateError('bad_manifest', u'%s' % err)
    if not parse_version(version):
        raise UpdateError('bad_manifest', u'version=%r' % version)
    if not is_newer(version, local['version']):
        return None
    return Update(version, url, manifest.get('sha256'), manifest.get('notes'), local['version'])


# --- o'rnatish ----------------------------------------------------------------

def sha256_of(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as f:
        while True:
            block = f.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def _safe_extract(zip_path, target):
    """Zip'ni ochadi; papkadan tashqariga yozmoqchi bo'lgan yozuv bo'lsa to'xtaydi."""
    root = os.path.abspath(target)
    archive = zipfile.ZipFile(zip_path)
    try:
        for name in archive.namelist():
            clean = name.replace('\\', '/')
            parts = [p for p in clean.split('/') if p]
            if clean.startswith('/') or ':' in clean or '..' in parts:
                raise UpdateError('bad_package', name)
            if not parts:
                continue
            path = os.path.join(root, *parts)
            if clean.endswith('/'):
                if not os.path.isdir(path):
                    os.makedirs(path)
                continue
            folder = os.path.dirname(path)
            if not os.path.isdir(folder):
                os.makedirs(folder)
            with open(path, 'wb') as f:
                f.write(archive.read(name))
    finally:
        archive.close()


def _package_root(folder):
    """Ochilgan paket ichida kengaytma ildizini topadi (version.json va lib/archstore bor joy)."""
    for current, dirs, files in os.walk(folder):
        if VERSION_FILE in files and os.path.isdir(os.path.join(current, 'lib', 'archstore')):
            return current
    raise UpdateError('bad_package', u'no %s' % VERSION_FILE)


def _files(root):
    found = set()
    for current, dirs, files in os.walk(root):
        for name in files:
            found.add(os.path.relpath(os.path.join(current, name), root).replace('\\', '/'))
    return found


def _looks_like_extension(path):
    return (os.path.basename(os.path.abspath(path)).lower().endswith('.extension')
            and os.path.isdir(os.path.join(path, 'lib', 'archstore')))


def backup(ext_dir, backup_dir, version):
    """Joriy versiyani zip qilib saqlaydi; faqat oxirgi bir nechtasi qoladi."""
    if not os.path.isdir(backup_dir):
        os.makedirs(backup_dir)
    target = os.path.join(backup_dir, 'ArchStoreBIM-%s.zip' % (version or '0'))
    archive = zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED)
    try:
        for rel in sorted(_files(ext_dir)):
            archive.write(os.path.join(ext_dir, *rel.split('/')), 'ArchStoreBIM.extension/' + rel)
    finally:
        archive.close()
    old = sorted((os.path.getmtime(os.path.join(backup_dir, n)), n)
                 for n in os.listdir(backup_dir) if n.lower().endswith('.zip'))
    for stamp, name in old[:-KEEP_BACKUPS]:
        try:
            os.remove(os.path.join(backup_dir, name))
        except OSError:
            pass
    return target


def mirror(source, target):
    """target'ni source bilan bir xil qiladi: yangi fayllar yoziladi, ortiqchalari o'chiriladi."""
    # noto'g'ri papkani tozalab yubormaslik uchun: faqat haqiqiy kengaytma papkasiga yozamiz
    if not _looks_like_extension(target) or not os.path.isdir(os.path.join(source, 'lib', 'archstore')):
        raise UpdateError('bad_target', target)
    wanted = _files(source)
    for rel in sorted(wanted):
        src = os.path.join(source, *rel.split('/'))
        dst = os.path.join(target, *rel.split('/'))
        folder = os.path.dirname(dst)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        shutil.copyfile(src, dst)
    for rel in sorted(_files(target) - wanted):
        try:
            os.remove(os.path.join(target, *rel.split('/')))
        except OSError:
            pass
    for current, dirs, files in os.walk(target, topdown=False):
        if current != target and not os.listdir(current):
            try:
                os.rmdir(current)
            except OSError:
                pass


def install(update, ext_dir=None, backup_dir=None, download=fetch_file):
    """Yangilanishni o'rnatadi; o'rnatilgan versiya raqamini qaytaradi."""
    ext_dir = ext_dir or extension_dir()
    if not _looks_like_extension(ext_dir):
        raise UpdateError('bad_target', ext_dir)
    if not update.sha256:
        raise UpdateError('checksum', u'manifest has no sha256')
    work = tempfile.mkdtemp(prefix='archstore_update_')
    try:
        package = os.path.join(work, 'package.zip')
        download(update.url, package)
        if sha256_of(package) != update.sha256:
            raise UpdateError('checksum', update.url)
        unpacked = os.path.join(work, 'unpacked')
        os.makedirs(unpacked)
        try:
            _safe_extract(package, unpacked)
        except UpdateError:
            raise
        except Exception as err:
            raise UpdateError('bad_package', u'%s' % err)
        root = _package_root(unpacked)
        inside = read_local(root)['version']
        if parse_version(inside) != parse_version(update.version):
            raise UpdateError('bad_package', u'%s != %s' % (inside, update.version))
        saved = backup(ext_dir, backup_dir, update.current) if backup_dir else None
        try:
            mirror(root, ext_dir)
        except Exception as err:
            if saved:                                   # yarim yozilgan holatda qoldirmaymiz
                try:
                    previous = os.path.join(work, 'previous')
                    os.makedirs(previous)
                    _safe_extract(saved, previous)
                    mirror(_package_root(previous), ext_dir)
                except Exception:
                    pass
            if isinstance(err, UpdateError):
                raise
            raise UpdateError('write', u'%s' % err)
        return inside
    finally:
        shutil.rmtree(work, ignore_errors=True)
