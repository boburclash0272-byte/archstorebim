# -*- coding: utf-8 -*-
"""Panel ranglari: yorug' va qorong'i mavzu.

Har bir kalit - ui.xaml ichidagi rang nomi (DynamicResource). Mavzu
almashganda shu ranglar oynaga qaytadan beriladi.

  Paper   - oyna foni              Panel  - chap ustun foni
  Surface - maydon va kartochka    Hover  - sichqoncha ostidagi qator
  Line    - chiziqlar              Ink    - asosiy matn va tanlangan qator foni
  OnInk   - Ink ustidagi matn      Muted  - ikkinchi darajali matn
  Warn    - ogohlantirish          Gold   - PRO va yulduzcha
  Badge   - PRO/yulduzcha foni     Thumb  - rasm ostidagi fon (Revit preview oq bo'ladi)
"""

MODES = ('auto', 'light', 'dark')       # auto = Revit qaysi mavzuda bo'lsa, o'sha

THEMES = {
    'light': {
        'Paper': '#F4F2EC', 'Panel': '#EBE8DF', 'Surface': '#FFFFFF', 'Hover': '#E2DED3',
        'Line': '#D9D5C9', 'Ink': '#1B1B19', 'OnInk': '#FFFFFF', 'Muted': '#676459',
        'Warn': '#B3401F', 'Gold': '#F0C36A', 'Badge': '#1B1B19', 'Thumb': '#FFFFFF',
    },
    # Revit 2024 qorong'i interfeysining o'z ranglari (ekrandan olingan):
    # asosiy fon #3B4453, maydonlar #2C3440, sarlavhalar #222933, varaqlar qatori #454F61
    'dark': {
        'Paper': '#3B4453', 'Panel': '#2C3440', 'Surface': '#454F61', 'Hover': '#4D586C',
        'Line': '#5A657A', 'Ink': '#F0F2F5', 'OnInk': '#222933', 'Muted': '#C0C7D2',
        'Warn': '#FFB8A2', 'Gold': '#F0C36A', 'Badge': '#1B1B19', 'Thumb': '#F2F2F2',
    },
}


def resolve(mode, revit_is_dark):
    """Sozlamadagi rejimdan ('auto' | 'light' | 'dark') haqiqiy mavzu nomini chiqaradi."""
    if mode == 'dark' or (mode not in ('light', 'dark') and revit_is_dark):
        return 'dark'
    return 'light'
