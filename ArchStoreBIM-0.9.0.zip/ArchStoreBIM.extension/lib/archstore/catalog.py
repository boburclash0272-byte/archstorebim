# -*- coding: utf-8 -*-
"""Kutubxona papkasidan katalog tuzish.

Papka tuzilishi:
  kutubxona/
    Mebel/              <- birinchi darajadagi papka = kategoriya
      Stul.rfa          <- har bir .rfa = bitta model
      Stul.png          <- (ixtiyoriy) o'z rasmingiz, bo'lmasa fayl ichidagi preview olinadi
      Stul.txt          <- (ixtiyoriy) Revit type catalog
    _materials/         <- (ixtiyoriy) materiallari bor .rvt fayllar
      Qoplamalar.rvt
    catalog.json        <- nom, teg, tavsif, brend, PRO belgisi va to'plamlar
                           (plagin ichidagi muharrir shu faylni yozadi)

Sevimlilar, oxirgi ishlatilganlar va til - foydalanuvchining o'z sozlamalarida
(%APPDATA%\\ArchStoreBIM\\settings.json), kutubxona papkasida emas.

Bu modul Revit'ga bog'liq emas, shuning uchun uni alohida sinash mumkin.
"""
import hashlib
import io
import json
import os
import re

from archstore import ole

MANIFEST = 'catalog.json'
MATERIALS_DIR = '_materials'
CACHE_VERSION = 2
RECENT_LIMIT = 40
_BACKUP = re.compile(r'\.\d{4}\.(rfa|rvt)$', re.IGNORECASE)
_IMG_EXT = ('.png', '.jpg', '.jpeg')
_TEXT = type(u'')


class CatalogError(Exception):
    pass


# --- sozlamalar --------------------------------------------------------------

def data_dir():
    base = os.environ.get('APPDATA') or os.path.expanduser('~')
    path = os.path.join(base, 'ArchStoreBIM')
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def _read_json(path, encoding='utf-8'):
    with io.open(path, 'r', encoding=encoding) as f:
        return json.load(f)


def _write_json(path, data, pretty=False):
    # ensure_ascii=False shart: IronPython 2.7 da json.dumps standart rejimda
    # "x", "°", "Ø" kabi belgilar (U+0080..U+00FF) uchrasa xato beradi.
    if pretty:
        text = json.dumps(data, indent=2, ensure_ascii=False, sort_keys=True)
    else:
        text = json.dumps(data, ensure_ascii=False)
    if not isinstance(text, _TEXT):
        text = text.decode('utf-8')
    with io.open(path, 'w', encoding='utf-8') as f:
        f.write(text)


def _settings_path():
    return os.path.join(data_dir(), 'settings.json')


def load_settings():
    try:
        data = _read_json(_settings_path())
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_settings(settings):
    _write_json(_settings_path(), settings, pretty=True)


def _norm(rel):
    return rel.replace('\\', '/').lower()


def _texts(values):
    return [v.strip() for v in values if isinstance(v, _TEXT) and v.strip()]


# --- model -------------------------------------------------------------------

class Item(object):
    """Katalogdagi bitta model."""

    def __init__(self, path, rel, category):
        self.path = path
        self.rel = rel                      # kutubxona ichidagi nisbiy yo'l, '/' bilan
        self.key = _norm(rel)
        self.category = category            # u'' = papkasiz (ildizda turgan) fayl
        self.family_name = os.path.splitext(os.path.basename(path))[0]
        self.title = self.family_name
        self.tags = []
        self.description = u''
        self.brand = u''
        self.access = 'free'                # 'free' yoki 'pro' - hozircha faqat belgi
        self.year = None                    # fayl saqlangan Revit versiyasi
        self.revit_category = None          # Revit'dagi kategoriya (Furniture, Doors...)
        self.types = []                     # [{'name':..., 'params': [[nom, qiymat], ...]}]
        self.has_type_catalog = False
        self.size = 0
        self.thumb_path = None

    @property
    def is_pro(self):
        return self.access == 'pro'

    def apply_meta(self, meta):
        self.title = meta.get('title') or self.family_name
        self.tags = _texts(meta.get('tags') or [])
        self.description = meta.get('description') or u''
        self.brand = (meta.get('brand') or u'').strip()
        self.access = 'pro' if meta.get('access') == 'pro' else 'free'

    def matches(self, query):
        if not query:
            return True
        hay = u' '.join([self.title, self.family_name, self.category, self.brand,
                         self.revit_category or u''] + self.tags).lower()
        return all(word in hay for word in query.lower().split())


class Material(object):
    """_materials papkasidagi .rvt fayl ichidagi bitta material."""

    def __init__(self, path, name, material_class, color):
        self.path = path
        self.name = name
        self.material_class = material_class or u''
        self.color = color                  # [r, g, b] yoki None
        self.collection = os.path.splitext(os.path.basename(path))[0]

    def matches(self, query):
        if not query:
            return True
        hay = u' '.join([self.name, self.material_class, self.collection]).lower()
        return all(word in hay for word in query.lower().split())


# --- kesh --------------------------------------------------------------------
# Har bir faylni bir marta o'qiymiz; natija fayl o'zgarmaguncha keshda turadi.

def _cache_dir():
    path = os.path.join(data_dir(), 'cache')
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def _index_path():
    return os.path.join(_cache_dir(), 'index.json')


def _load_index():
    try:
        data = _read_json(_index_path())
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _stamp(path):
    st = os.stat(path)
    return u'%d-%d' % (int(st.st_mtime), st.st_size)


def _key(path):
    return hashlib.md5(os.path.abspath(path).lower().encode('utf-8')).hexdigest()


def _own_image(path):
    base = os.path.splitext(path)[0]
    for ext in _IMG_EXT:
        if os.path.isfile(base + ext):
            return base + ext
    return None


# --- kutubxona ---------------------------------------------------------------

class Library(object):
    def __init__(self, root):
        self.root = root
        self._root_key = os.path.abspath(root).lower()
        self.items = []
        self._by_key = {}
        self._meta = {}         # {norm rel: {...}}
        self._keys = {}         # {norm rel: catalog.json'dagi asl kalit}
        self._sets = {}         # {nom: [rel, ...]}
        self._extra = {}        # catalog.json'dagi biz bilmagan boshqa maydonlar
        self._broken = False    # catalog.json bor, lekin o'qib bo'lmadi
        self.reload()

    # --- o'qish ---

    def reload(self):
        self._load_manifest()
        self.items = self._scan()
        self._by_key = dict((i.key, i) for i in self.items)

    def _manifest_path(self):
        return os.path.join(self.root, MANIFEST)

    def _load_manifest(self):
        self._meta, self._keys, self._sets, self._extra = {}, {}, {}, {}
        self._broken = False
        path = self._manifest_path()
        if not os.path.isfile(path):
            return
        try:
            data = _read_json(path, 'utf-8-sig')
            if not isinstance(data, dict):
                raise ValueError('not an object')
        except Exception:
            self._broken = True
            return
        for key, meta in (data.get('items') or {}).items():
            if isinstance(meta, dict):
                self._meta[_norm(key)] = meta
                self._keys[_norm(key)] = key
        for name, rels in (data.get('sets') or {}).items():
            if isinstance(rels, list):
                self._sets[name] = _texts(rels)
        self._extra = dict((k, v) for k, v in data.items() if k not in ('items', 'sets'))

    def _scan(self):
        items = []
        for folder, dirs, files in os.walk(self.root):
            dirs[:] = sorted(d for d in dirs if not d.startswith(('.', '_')))
            for name in sorted(files):
                if not name.lower().endswith('.rfa') or _BACKUP.search(name):
                    continue
                path = os.path.join(folder, name)
                rel = os.path.relpath(path, self.root).replace('\\', '/')
                parts = rel.split('/')
                item = Item(path, rel, parts[0] if len(parts) > 1 else u'')
                item.apply_meta(self._meta.get(item.key, {}))
                items.append(item)
        items.sort(key=lambda i: (i.category == u'', i.category.lower(), i.title.lower()))
        return items

    def enrich(self, progress=None):
        """Har bir modelga rasm, versiya, Revit kategoriyasi va tiplarni biriktiradi.

        progress(done, total) - ixtiyoriy, uzoq davom etsa ko'rsatkich uchun.
        Yangi o'qilgan fayllar sonini qaytaradi.
        """
        index = _load_index()
        cache = _cache_dir()
        fresh = 0
        total = len(self.items)
        for n, item in enumerate(self.items):
            key = _key(item.path)
            catalog_txt = os.path.splitext(item.path)[0] + '.txt'
            try:
                item.size = os.stat(item.path).st_size
                stamp = _stamp(item.path)
                if os.path.isfile(catalog_txt):
                    stamp += u'+' + _stamp(catalog_txt)
            except OSError:
                continue
            rec = index.get(key)
            png_path = os.path.join(cache, key + '.png')
            if not rec or rec.get('stamp') != stamp or rec.get('v') != CACHE_VERSION:
                info = ole.inspect(item.path)
                if info['png']:
                    ole.write_file(png_path, info['png'])
                types = info['types']
                listed = ole.type_catalog(catalog_txt) if os.path.isfile(catalog_txt) else []
                rec = {'v': CACHE_VERSION, 'stamp': stamp, 'year': info['year'],
                       'thumb': bool(info['png']), 'rcat': info['category'],
                       'types': listed or types, 'tc': bool(listed)}
                index[key] = rec
                fresh += 1
                if progress:
                    progress(n + 1, total)
            item.year = rec.get('year')
            item.revit_category = rec.get('rcat')
            item.types = rec.get('types') or []
            item.has_type_catalog = bool(rec.get('tc'))
            item.thumb_path = _own_image(item.path) or (
                png_path if rec.get('thumb') and os.path.isfile(png_path) else None)
        if fresh:
            _write_json(_index_path(), index)
        return fresh

    # --- catalog.json yozish (muharrir) ---

    def _save_manifest(self):
        if self._broken:
            raise CatalogError('broken')
        items = {}
        for key, meta in self._meta.items():
            if not meta:
                continue
            item = self._by_key.get(key)
            items[item.rel if item else self._keys.get(key, key)] = meta
        data = dict(self._extra)
        data['items'] = items
        data['sets'] = dict((n, r) for n, r in self._sets.items() if r)
        try:
            _write_json(self._manifest_path(), data, pretty=True)
        except (IOError, OSError):
            raise CatalogError('readonly')

    def update_meta(self, items, title=None, brand=None, tags=None, add_tags=None,
                    description=None, pro=None):
        """Modellar ma'lumotini o'zgartiradi. None = bu maydonga tegilmaydi."""
        if self._broken:
            raise CatalogError('broken')
        for item in items:
            meta = dict(self._meta.get(item.key, {}))
            if title is not None:
                title = title.strip()
                if title and title != item.family_name:
                    meta['title'] = title
                else:
                    meta.pop('title', None)
            if brand is not None:
                if brand.strip():
                    meta['brand'] = brand.strip()
                else:
                    meta.pop('brand', None)
            if tags is not None:
                meta['tags'] = _texts(tags)
            if add_tags:
                have = _texts(meta.get('tags') or [])
                low = set(t.lower() for t in have)
                meta['tags'] = have + [t for t in _texts(add_tags) if t.lower() not in low]
            if 'tags' in meta and not meta['tags']:
                del meta['tags']
            if description is not None:
                if description.strip():
                    meta['description'] = description.strip()
                else:
                    meta.pop('description', None)
            if pro is True:
                meta['access'] = 'pro'
            elif pro is False:
                meta.pop('access', None)
            self._meta[item.key] = meta
            item.apply_meta(meta)
        self._save_manifest()

    # --- to'plamlar ---

    def set_names(self):
        return sorted(self._sets, key=lambda n: n.lower())

    def set_items(self, name):
        found = [self._by_key.get(_norm(rel)) for rel in self._sets.get(name, [])]
        return [i for i in found if i]

    def add_to_set(self, name, items):
        name = name.strip()
        if not name:
            return
        rels = list(self._sets.get(name, []))
        have = set(_norm(r) for r in rels)
        rels += [i.rel for i in items if i.key not in have]
        self._sets[name] = rels
        self._save_manifest()

    def remove_from_set(self, name, items):
        gone = set(i.key for i in items)
        self._sets[name] = [r for r in self._sets.get(name, []) if _norm(r) not in gone]
        if not self._sets[name]:
            del self._sets[name]
        self._save_manifest()

    # --- guruhlar ---

    def categories(self):
        """[(nom, soni), ...]; papkasiz fayllar (nom u'') oxirida."""
        return self._counts(i.category for i in self.items)

    def brands(self):
        return self._counts(i.brand for i in self.items if i.brand)

    @staticmethod
    def _counts(values):
        counts = {}
        for v in values:
            counts[v] = counts.get(v, 0) + 1
        return [(n, counts[n]) for n in sorted(counts, key=lambda n: (n == u'', n.lower()))]

    # --- sevimlilar va oxirgilar (foydalanuvchi sozlamalarida) ---

    def _user_list(self, name):
        return list(load_settings().get(name, {}).get(self._root_key, []))

    def _save_user_list(self, name, keys):
        settings = load_settings()
        settings.setdefault(name, {})[self._root_key] = keys
        save_settings(settings)

    def favorite_keys(self):
        return set(self._user_list('favorites'))

    def toggle_favorite(self, items):
        """Hammasi sevimli bo'lsa - olib tashlaydi, aks holda qo'shadi. Yangi holatni qaytaradi."""
        keys = self._user_list('favorites')
        on = not all(i.key in keys for i in items)
        for item in items:
            if on and item.key not in keys:
                keys.append(item.key)
            elif not on and item.key in keys:
                keys.remove(item.key)
        self._save_user_list('favorites', keys)
        return on

    def touch_recent(self, items):
        keys = self._user_list('recent')
        for item in items:
            if item.key in keys:
                keys.remove(item.key)
            keys.insert(0, item.key)
        self._save_user_list('recent', keys[:RECENT_LIMIT])

    def favorites(self):
        keys = self.favorite_keys()
        return [i for i in self.items if i.key in keys]

    def recent(self):
        found = [self._by_key.get(k) for k in self._user_list('recent')]
        return [i for i in found if i]

    # --- qidiruv ---

    def find(self, kind='all', value=None, query=None):
        """kind: all | fav | recent | cat | brand | set."""
        if kind == 'fav':
            pool = self.favorites()
        elif kind == 'recent':
            pool = self.recent()
        elif kind == 'cat':
            pool = [i for i in self.items if i.category == value]
        elif kind == 'brand':
            pool = [i for i in self.items if i.brand == value]
        elif kind == 'set':
            pool = self.set_items(value)
        else:
            pool = self.items
        return [i for i in pool if i.matches(query)]

    # --- materiallar ---
    # Material ro'yxatini bilish uchun .rvt faylni Revit ochishi kerak, shuning
    # uchun buni Revit tomoni (script.py) qiladi va natijani shu yerga saqlaydi.

    def material_files(self):
        folder = os.path.join(self.root, MATERIALS_DIR)
        if not os.path.isdir(folder):
            return []
        return [os.path.join(folder, n) for n in sorted(os.listdir(folder))
                if n.lower().endswith('.rvt') and not _BACKUP.search(n)]

    def materials(self):
        """(materiallar, hali o'qilmagan fayllar) qaytaradi."""
        index = _load_index()
        found, pending = [], []
        for path in self.material_files():
            rec = index.get('m:' + _key(path))
            try:
                stamp = _stamp(path)
            except OSError:
                continue
            if not rec or rec.get('stamp') != stamp:
                pending.append(path)
                continue
            for m in rec.get('materials', []):
                found.append(Material(path, m.get('name', u''), m.get('class'), m.get('color')))
        found.sort(key=lambda m: (m.collection.lower(), m.name.lower()))
        return found, pending

    def store_materials(self, path, records):
        """records: [{'name':..., 'class':..., 'color': [r, g, b] yoki None}, ...]"""
        index = _load_index()
        index['m:' + _key(path)] = {'stamp': _stamp(path), 'materials': records}
        _write_json(_index_path(), index)
