# -*- coding: utf-8 -*-
"""Umumiy uslublarni asbob oynasiga qo'shish.

Har bir asbobning ui.xaml fayli <Window.Resources> ichida shu belgini saqlaydi:

    <!--ARCHSTORE:STYLES-->

Oyna ochilganda belgi o'rniga styles.xamlpart (ranglar va umumiy tugma, sarlavha,
maydon uslublari) qo'yiladi. Shunda rang yoki tugma ko'rinishi bitta joyda
o'zgartiriladi va hamma oynaga ta'sir qiladi.
"""
import hashlib
import io
import os

from archstore import catalog

MARKER = u'<!--ARCHSTORE:STYLES-->'
PART = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'styles.xamlpart')


def _read(path):
    with io.open(path, 'r', encoding='utf-8') as f:
        return f.read()


def compose(xaml_path):
    """Umumiy uslublar qo'shilgan XAML faylining yo'lini qaytaradi.

    Natija keshda saqlanadi (%APPDATA%\\ArchStoreBIM\\cache); asbob fayli yoki
    umumiy uslublar o'zgarsa, yangisi yoziladi. Belgi bo'lmasa fayl o'zi qaytadi.
    """
    source = _read(xaml_path)
    if MARKER not in source:
        return xaml_path
    stamp = u'%s|%s|%s' % (os.path.abspath(xaml_path).lower(),
                           os.path.getmtime(xaml_path), os.path.getmtime(PART))
    name = 'ui_%s.xaml' % hashlib.md5(stamp.encode('utf-8')).hexdigest()
    folder = os.path.join(catalog.data_dir(), 'cache')
    if not os.path.isdir(folder):
        os.makedirs(folder)
    target = os.path.join(folder, name)
    if not os.path.isfile(target):
        with io.open(target, 'w', encoding='utf-8') as f:
            f.write(source.replace(MARKER, _read(PART)))
    return target
