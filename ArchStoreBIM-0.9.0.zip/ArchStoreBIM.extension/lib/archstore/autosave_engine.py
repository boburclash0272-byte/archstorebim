# -*- coding: utf-8 -*-
"""Avtosaqlashning Revit ichida ishlaydigan qismi.

Tuzilishi:
  - DispatcherTimer har 10 soniyada sozlamani o'qiydi va vaqt yetgan bo'lsa
    ExternalEvent'ni chaqiradi;
  - ExternalEvent faqat Revit bo'sh bo'lganda ishlaydi, shuning uchun saqlash
    hech qachon buyruq o'rtasida boshlanmaydi;
  - ishlab turgan taymer pyRevit muhit o'zgaruvchisida saqlanadi, shunda u
    ikki marta ishga tushmaydi va Reload'dan keyin eskisi to'xtatiladi.

Revit ishga tushganda startup.py, keyin esa Avtosaqlash oynasi shu modulni chaqiradi.
"""
import time

import clr

clr.AddReference('WindowsBase')

from System import TimeSpan
from System.Windows.Threading import DispatcherTimer

from pyrevit import UI, script

from archstore import autosave, catalog

TIMER_VAR = 'ARCHSTOREBIM_AUTOSAVE_TIMER'    # ishlab turgan taymer (.NET obyekti)
BEAT_VAR = 'ARCHSTOREBIM_AUTOSAVE_BEAT'      # taymer oxirgi marta qachon "urgani" (tiriklik belgisi)
LAST_VAR = 'ARCHSTOREBIM_AUTOSAVE_LAST'      # vaqt hisobi qachondan boshlangani
CHECK_SECONDS = 10
_engine = [None]            # shu dvigatelda yaratilgan obyektni tirik ushlab turadi


def save_documents(app):
    """Ochiq, o'zgargan va diskda joyi bor hujjatlarni saqlaydi (Ctrl+S kabi).
    Qaytaradi: (saqlanganlar, hali hech qachon saqlanmaganlar, birinchi xato matni)."""
    saved, unsaved, error = [], [], u''
    for doc in app.Documents:
        try:
            if doc.IsLinked or doc.IsReadOnly or doc.IsModifiable or not doc.IsModified:
                continue
            if not doc.PathName:
                unsaved.append(doc.Title)       # fayl nomi yo'q - birinchi marta qo'lda saqlash kerak
                continue
            doc.Save()
            saved.append(doc.Title)
        except Exception as err:
            if not error:
                error = u'%s' % err
    return saved, unsaved, error


class Saver(UI.IExternalEventHandler):
    def __init__(self):
        self.pending = False

    def Execute(self, uiapp):
        self.pending = False
        try:
            saved, unsaved, error = save_documents(uiapp.Application)
            if saved or unsaved or error:
                settings = catalog.load_settings()
                autosave.record(settings, time.strftime('%Y-%m-%d %H:%M'), len(saved), unsaved, error)
                catalog.save_settings(settings)
        except Exception:
            pass                            # avtosaqlash hech qachon Revit ishiga xalaqit bermasligi kerak

    def GetName(self):
        return 'ArchStore BIM autosave'


class Engine(object):
    def __init__(self):
        self.saver = Saver()
        self.event = UI.ExternalEvent.Create(self.saver)
        self.mark(time.time())
        script.set_envvar(BEAT_VAR, self.last)
        self.timer = DispatcherTimer()
        self.timer.Interval = TimeSpan.FromSeconds(CHECK_SECONDS)
        self.timer.Tick += self.on_tick
        self.timer.Start()

    def mark(self, moment):
        """Vaqt hisobini shu paytdan boshlaydi (boshqa oynalar ham ko'rishi uchun e'lon qiladi)."""
        self.last = moment
        script.set_envvar(LAST_VAR, moment)

    def on_tick(self, sender, args):
        try:
            now = time.time()
            script.set_envvar(BEAT_VAR, now)
            started = script.get_envvar(LAST_VAR)   # oyna hisobni qayta boshlagan bo'lishi mumkin
            if started is not None:
                self.last = started
            config = autosave.read(catalog.load_settings())
            if not config['enabled']:
                self.mark(now)              # qayta yoqilganda hisob boshidan boshlanadi
                return
            if autosave.due(now, self.last, config['minutes']) and not self.saver.pending:
                self.saver.pending = True
                self.mark(now)
                self.event.Raise()
        except Exception:
            pass


def running():
    try:
        timer = script.get_envvar(TIMER_VAR)
        return timer is not None and timer.IsEnabled
    except Exception:
        return False


def alive():
    """Taymer haqiqatan ishlayaptimi: oxirgi "urish" yaqinda bo'lganmi."""
    try:
        beat = script.get_envvar(BEAT_VAR)
        return running() and beat is not None and (time.time() - beat) < CHECK_SECONDS * 3 + 10
    except Exception:
        return False


def remaining_minutes():
    """Keyingi avtosaqlashgacha taxminan necha daqiqa qoldi; noma'lum bo'lsa None."""
    try:
        started = script.get_envvar(LAST_VAR)
        if started is None:
            return None
        config = autosave.read(catalog.load_settings())
        return autosave.remaining_minutes(time.time(), started, config['minutes'])
    except Exception:
        return None


def restart_countdown():
    """Vaqt hisobini hozirdan boshlaydi (yoqilganda yoki oraliq o'zgarganda)."""
    if _engine[0] is not None:
        _engine[0].mark(time.time())
    else:
        script.set_envvar(LAST_VAR, time.time())    # boshqa dvigateldagi taymer keyingi urishda hisobga oladi


def ensure_running(restart=False):
    """Avtosaqlash dvigatelini ishga tushiradi.
    restart=True - eski taymer to'xtatilib, yangisi yaratiladi (Revit ochilganda / Reload'dan keyin).
    Aks holda tirik taymer bo'lsa, unga tegilmaydi."""
    if alive() and not restart:
        return _engine[0]
    try:
        old = script.get_envvar(TIMER_VAR)
        if old is not None:
            old.Stop()
    except Exception:
        pass
    engine = Engine()
    _engine[0] = engine
    script.set_envvar(TIMER_VAR, engine.timer)
    return engine
