# -*- coding: utf-8 -*-
"""Revit fayllari (.rfa/.rvt) ichidan ma'lumot o'qish.

Revit fayli - OLE "compound file". Uning ichida ikkita foydali oqim bor:
  RevitPreview4.0 - preview rasm (PNG)
  BasicFileInfo   - fayl qaysi Revit versiyasida saqlangani

Faylni Revit'da ochmasdan, to'g'ridan-to'g'ri baytlardan o'qiymiz.
Kod IronPython 2.7 / 3.4 va oddiy Python 3 da bir xil ishlaydi,
shuning uchun hamma joyda bytearray ishlatiladi (struct yo'q).
"""
import re
import sys

IS_CLI = sys.platform == 'cli'

_MAGIC = bytearray([0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1])
_PNG_HEAD = bytearray([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])
_PNG_TAIL = bytearray([0x49, 0x45, 0x4E, 0x44, 0xAE, 0x42, 0x60, 0x82])
_END = 0xFFFFFFFE          # zanjir oxiri
_MAX_REG = 0xFFFFFFFA      # bundan katta qiymatlar - maxsus belgilar


def read_file(path):
    """Faylni bytearray qilib o'qish."""
    if IS_CLI:
        from System.IO import File
        return bytearray(File.ReadAllBytes(path))
    with open(path, 'rb') as f:
        return bytearray(f.read())


def write_file(path, data):
    """bytearray'ni faylga yozish."""
    if IS_CLI:
        from System import Array, Byte
        from System.IO import File
        File.WriteAllBytes(path, Array[Byte](list(data)))
        return
    with open(path, 'wb') as f:
        f.write(data)


def _u16(b, o):
    return b[o] | (b[o + 1] << 8)


def _u32(b, o):
    return b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)


class OleFile(object):
    """Compound file'ning minimal o'quvchisi (faqat o'qish)."""

    def __init__(self, data):
        if len(data) < 512 or data[0:8] != _MAGIC:
            raise ValueError('OLE fayl emas')
        self.data = data
        self.sec_size = 1 << _u16(data, 30)
        self.mini_size = 1 << _u16(data, 32)
        self.mini_cutoff = _u32(data, 56)
        self.fat = self._load_fat()
        self.entries = self._load_dir(_u32(data, 48))
        self.minifat = self._load_minifat(_u32(data, 60))
        root = self.entries[0] if self.entries else None
        self.ministream = (self._read_chain(root['start'], root['size'])
                           if root and root['size'] else bytearray())

    def _sector(self, n):
        off = (n + 1) * self.sec_size
        return self.data[off:off + self.sec_size]

    def _load_fat(self):
        d = self.data
        per = self.sec_size // 4
        fat_sectors = []
        for i in range(109):
            s = _u32(d, 76 + i * 4)
            if s <= _MAX_REG:
                fat_sectors.append(s)
        # katta fayllarda FAT ro'yxati qo'shimcha (DIFAT) sektorlarda davom etadi
        nxt = _u32(d, 68)
        guard = 0
        while nxt <= _MAX_REG and guard < 100000:
            sec = self._sector(nxt)
            if len(sec) < self.sec_size:
                break
            for i in range(per - 1):
                s = _u32(sec, i * 4)
                if s <= _MAX_REG:
                    fat_sectors.append(s)
            nxt = _u32(sec, (per - 1) * 4)
            guard += 1
        fat = []
        for s in fat_sectors:
            sec = self._sector(s)
            for i in range(len(sec) // 4):
                fat.append(_u32(sec, i * 4))
        return fat

    def _chain(self, start):
        out = []
        s = start
        limit = len(self.fat)
        while s <= _MAX_REG and s < limit and len(out) <= limit:
            out.append(s)
            s = self.fat[s]
        return out

    def _read_chain(self, start, size=None):
        buf = bytearray()
        for s in self._chain(start):
            buf.extend(self._sector(s))
            if size is not None and len(buf) >= size:
                break
        return buf if size is None else buf[:size]

    def _load_dir(self, start):
        raw = self._read_chain(start)
        entries = []
        v3 = self.sec_size == 512
        for o in range(0, len(raw) - 127, 128):
            name_len = _u16(raw, o + 64)
            kind = raw[o + 66]
            if kind == 0 or name_len < 2 or name_len > 64:
                entries.append(None)
                continue
            name = raw[o:o + name_len - 2].decode('utf-16-le', 'ignore')
            size = _u32(raw, o + 120)
            if not v3:
                size |= _u32(raw, o + 124) << 32
            entries.append({'name': name, 'kind': kind,
                            'start': _u32(raw, o + 116), 'size': size})
        return entries

    def _load_minifat(self, start):
        raw = self._read_chain(start)
        return [_u32(raw, i * 4) for i in range(len(raw) // 4)]

    def stream(self, name):
        """Nomi bo'yicha oqimni qaytaradi, topilmasa None."""
        for e in self.entries:
            if e and e['kind'] == 2 and e['name'] == name:
                break
        else:
            return None
        if e['size'] >= self.mini_cutoff:
            return self._read_chain(e['start'], e['size'])
        buf = bytearray()
        s = e['start']
        limit = len(self.minifat)
        steps = 0
        while s <= _MAX_REG and s < limit and steps <= limit:
            off = s * self.mini_size
            buf.extend(self.ministream[off:off + self.mini_size])
            s = self.minifat[s]
            steps += 1
        return buf[:e['size']]


def _preview_png(ole):
    raw = ole.stream('RevitPreview4.0')
    if not raw:
        return None
    a = raw.find(_PNG_HEAD)
    if a < 0:
        return None
    b = raw.find(_PNG_TAIL, a)
    if b < 0:
        return None
    return raw[a:b + len(_PNG_TAIL)]


def _revit_year(ole):
    raw = ole.stream('BasicFileInfo')
    if not raw:
        return None
    for enc in ('utf-16-le', 'utf-16-be'):
        text = raw.decode(enc, 'ignore')
        m = (re.search(r'Format:\s*(\d{4})', text)
             or re.search(r'Autodesk Revit[^\d\r\n]{0,20}(\d{4})', text))
        if m:
            return int(m.group(1))
    return None


_ENTITIES = (('&lt;', u'<'), ('&gt;', u'>'), ('&quot;', u'"'), ('&apos;', u"'"), ('&amp;', u'&'))
_PART = re.compile(r'<A:part\b[^>]*>(.*?)</A:part>', re.S)
_TITLE = re.compile(r'<title>(.*?)</title>', re.S)
_PARAM = re.compile(r'<([^\s<>/!?]+)((?:\s[^<>]*)?)>([^<]*)</\1>')
_ATTR = re.compile(r'([\w:.-]+)="([^"]*)"')
MAX_TYPES = 80
MAX_PARAMS = 8


def _unescape(text):
    for a, b in _ENTITIES:
        text = text.replace(a, b)
    return text.strip()


def _part_atom(ole):
    """PartAtom (XML) oqimidan: Revit kategoriyasi, versiya va tiplar.

    Tip = {'name': ..., 'params': [[nom, qiymat], ...]} - faqat uzunlik
    (Length) parametrlari olinadi, ya'ni o'lchamlar.
    """
    raw = ole.stream('PartAtom')
    if not raw:
        return None, None, []
    xml = raw.decode('utf-8', 'ignore')
    m = re.search(r'<category>\s*<term>(.*?)</term>', xml, re.S)
    category = _unescape(m.group(1)) if m else None
    m = re.search(r'<A:product-version>\s*(\d{4})', xml)
    year = int(m.group(1)) if m else None
    types = []
    for part in _PART.findall(xml)[:MAX_TYPES]:
        t = _TITLE.search(part)
        if not t:
            continue
        params = []
        for tag, attrs, value in _PARAM.findall(part):
            if tag in ('title', 'Default_Elevation') or not value.strip():
                continue
            a = dict(_ATTR.findall(attrs))
            if a.get('typeOfParameter') != 'Length':
                continue
            name = _unescape(a.get('displayName') or tag.replace('_', ' '))
            value = _unescape(value)
            if a.get('units') and not value.endswith(a['units']):
                value = u'%s %s' % (value, a['units'])
            params.append([name, value])
            if len(params) >= MAX_PARAMS:
                break
        types.append({'name': _unescape(t.group(1)), 'params': params})
    return category, year, types


def inspect(path):
    """Faylni Revit'da ochmasdan o'qiydi.

    Qaytaradi: {'png': baytlar yoki None, 'year': yil yoki None,
                'category': Revit kategoriyasi yoki None, 'types': [...]}
    """
    info = {'png': None, 'year': None, 'category': None, 'types': []}
    try:
        ole = OleFile(read_file(path))
    except Exception:
        return info
    try:
        info['png'] = _preview_png(ole)
    except Exception:
        pass
    try:
        info['year'] = _revit_year(ole)
    except Exception:
        pass
    try:
        category, year, types = _part_atom(ole)
        info['category'] = category
        info['types'] = types
        info['year'] = info['year'] or year
    except Exception:
        pass
    return info


# --- type catalog (.txt) ----------------------------------------------------

def _split_csv(line):
    out, cur, quoted, i = [], [], False, 0
    while i < len(line):
        ch = line[i]
        if ch == '"':
            if quoted and line[i + 1:i + 2] == '"':
                cur.append('"')
                i += 1
            else:
                quoted = not quoted
        elif ch == ',' and not quoted:
            out.append(u''.join(cur))
            cur = []
        else:
            cur.append(ch)
        i += 1
    out.append(u''.join(cur))
    return [c.strip() for c in out]


def _decode_text(raw):
    if raw[0:2] in (bytearray([0xFF, 0xFE]), bytearray([0xFE, 0xFF])):
        return raw.decode('utf-16', 'ignore')
    if raw[0:3] == bytearray([0xEF, 0xBB, 0xBF]):
        return raw[3:].decode('utf-8', 'ignore')
    try:
        return raw.decode('utf-8')
    except Exception:
        return raw.decode('cp1251', 'ignore')


_UNITS = {'MILLIMETERS': u'mm', 'CENTIMETERS': u'cm', 'METERS': u'm',
          'FEET': u'ft', 'INCHES': u'in'}


def type_catalog(path):
    """Family yonidagi type catalog (.txt) faylini o'qiydi.

    Birinchi qator - sarlavha (",Width##LENGTH##MILLIMETERS,..."),
    keyingi har bir qator - bitta tip. Xato bo'lsa bo'sh ro'yxat.
    """
    try:
        lines = [l for l in _decode_text(read_file(path)).splitlines() if l.strip()]
    except Exception:
        return []
    if len(lines) < 2:
        return []
    cols = []
    for field in _split_csv(lines[0])[1:]:
        bits = field.split('##')
        kind = bits[1].upper() if len(bits) > 1 else ''
        unit = _UNITS.get(bits[2].upper(), u'') if len(bits) > 2 else u''
        cols.append((bits[0], kind, unit))
    types = []
    for line in lines[1:MAX_TYPES + 1]:
        cells = _split_csv(line)
        if not cells or not cells[0]:
            continue
        params = []
        for (name, kind, unit), value in zip(cols, cells[1:]):
            if kind == 'LENGTH' and value and len(params) < MAX_PARAMS:
                params.append([name, (u'%s %s' % (value, unit)).strip()])
        types.append({'name': cells[0], 'params': params})
    return types
