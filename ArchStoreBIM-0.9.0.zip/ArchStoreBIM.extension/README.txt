ArchStore BIM (pyRevit kengaytmasi)

O'RNATISH
0. Eng oson yo'l: ArchStoreBIM-Setup-<versiya>.exe ni ishga tushiring (pyRevit o'rnatilgan bo'lishi kerak).
   Qo'lda o'rnatish:
1. "ArchStoreBIM.extension" papkasini shu yerga ko'chiring:
   %APPDATA%\pyRevit\Extensions
2. Revit'da: pyRevit tab > Reload.
3. "ArchStore BIM" tabi > Katalog. Birinchi ochilishda modellar turgan papkani so'raydi.
   Oyna Revit yonida ochiq turadi; tugmani qayta bossangiz, ochiq oyna oldinga chiqadi.

KUTUBXONA PAPKASI
  Modellar\
    Mebel\             birinchi darajadagi papka = kategoriya
      Stul.rfa         har bir .rfa = bitta model
      Stul.png         ixtiyoriy: o'z rasmingiz (bo'lmasa fayl ichidagi preview olinadi)
      Stul.txt         ixtiyoriy: Revit type catalog (tiplar shu yerdan olinadi)
    _materials\        ixtiyoriy: materiallari bor .rvt fayllar (har bir fayl = bitta to'plam)
      Qoplamalar.rvt
    catalog.json       nom, teg, tavsif, brend, PRO belgisi va to'plamlar.
                       Qo'lda yozish shart emas - plagin ichidagi "Tahrirlash" shu faylni yozadi.

NIMALAR BOR
- Bo'limlar: Barchasi, Sevimlilar, Oxirgi ishlatilganlar, Materiallar, kategoriyalar, brendlar, to'plamlar.
- Model sahifasi (o'ng ustun): katta rasm, Revit kategoriyasi va versiyasi, fayl hajmi, tavsif, teglar,
  tiplar va ularning o'lchamlari. Tipni tanlab "Joylashtirish" bosiladi.
- Tahrirlash: bitta modelga nom/brend/teg/tavsif/PRO; bir nechta model tanlansa - brend, teg va PRO
  hammasiga birga qo'yiladi.
- To'plamlar: modellarni tanlab "To'plamga qo'shish"; to'plam ichida hech narsa tanlanmagan bo'lsa,
  "To'plamni yuklash" hammasini birga yuklaydi.
- Materiallar: "Loyihaga yuklash" materialni ko'chiradi, "Sirtga qo'llash" - sirtlarni ketma-ket
  tanlaysiz, Esc bilan tugatasiz.
- Til: yuqori o'ngda UZ / RU / EN (yoki "Sozlamalar" oynasida).

ESLATMA
- Zaxira fayllar (Stul.0001.rfa) va "_" yoki "." bilan boshlanadigan papkalar modellar orasida ko'rsatilmaydi.
- Loyihada shu nomli family yoki material bo'lsa, u o'zgartirilmaydi.
- Sevimlilar, oxirgilar va til har bir foydalanuvchining o'zida saqlanadi
  (%APPDATA%\ArchStoreBIM\settings.json), kutubxona papkasida emas.
- Material fayllari kichik, worksharing'siz .rvt bo'lsin: ro'yxatni o'qish uchun Revit ularni fonda ochadi.
- PRO hozircha faqat belgi: lib\archstore\access.py ichida hamma model ochiq.

LENTADAGI BO'LIMLAR
- Modellar: Katalog (model kutubxonasi)
- Pardoz: Pol
- Oformleniya: Listlar, Nomerator
- Loyiha: Avtosaqlash, Saqlash
- Sozlamalar: Sozlamalar (mavzu, til, yangilanish)
Tartib "ArchStore BIM.tab\bundle.yaml" faylida yozilgan; yangi bo'lim qo'shilsa, o'sha ro'yxatga ham yoziladi.

AVTOSAQLASH ("Loyiha" bo'limi)
- Oynada yoqish/o'chirish tugmasi va oraliq: 15 daqiqa, 30 daqiqa yoki 1 soat.
- Ochiq turgan va o'zgargan fayllar Ctrl+S bosilgandek saqlanadi. Revit buyruq bilan band bo'lsa, bo'shashini kutadi.
- Hali hech qachon saqlanmagan fayl (nomi yo'q) saqlanmaydi - uni avval bir marta qo'lda saqlang.
- Sozlama eslab qolinadi; Revit keyingi safar ochilganda avtosaqlash o'zi ishlab ketadi (startup.py).

YANGILANISH
- "Sozlamalar" oynasidagi "Yangilanishni tekshirish" tugmasi yangi versiyani tekshiradi va rozilik bilan o'rnatadi.
- Katalog ochilganda kuniga bir marta fonda tekshiriladi; yangi versiya bo'lsa, chap ustunda "Yangilash" tugmasi chiqadi.
- O'rnatishdan oldin joriy versiya %APPDATA%\ArchStoreBIM\backup papkasiga zaxiralanadi (oxirgi 3 tasi).
- Yuklangan fayl nazorat yig'indisi (sha256) bilan tekshiriladi; mos kelmasa hech narsa o'zgarmaydi.
- Versiya va yangilanish manzili: version.json (kengaytma ildizida).

RANGLAR VA USLUBLAR (HAMMA OYNALAR UCHUN BITTA JOY)
- lib\archstore\theme.py        - yorug' va qorong'i mavzu ranglari. Shu yerda o'zgartirilgan rang hamma oynada o'zgaradi.
- lib\archstore\styles.xamlpart - umumiy tugma, sarlavha va maydon uslublari. Har oynaga ochilishda qo'shiladi.
- Mavzu (Revit kabi / Yorug' / Qorong'i) "Sozlamalar" oynasida tanlanadi va hamma asboblarga taalluqli.

YANGI ASBOB QO'SHISH
1. Papka: "ArchStore BIM.tab\<Bo'lim>.panel\<Nom>.pushbutton\" ichida script.py, ui.xaml, icon.png.
   Bo'lim yangi bo'lsa, uni "ArchStore BIM.tab\bundle.yaml" ro'yxatiga qo'shing.
2. ui.xaml: <Window.Resources> ichiga <!--ARCHSTORE:STYLES--> belgisini qo'ying; rang faqat
   {DynamicResource Ink} kabi nomlar orqali, tugmalar Style="{StaticResource Btn}" / BtnPrimary.
3. script.py: oyna klassi archstore.ui.ToolWindow dan olinadi - uslub va mavzu o'zi qo'llanadi.
4. Matnlar lib\archstore\i18n.py ga uch tilda yoziladi (T('kalit')).
5. Tranzaksiya: "from archstore.rvt import Tx" -> "with Tx(doc, APP + u': nom'):" (xato bo'lsa o'zi bekor qilinadi).
6. Revit'ga bog'liq bo'lmagan hisob-kitob alohida faylga (lib\archstore\<nom>.py) yoziladi - uni Revit'siz tekshirish mumkin.

POL TUGMASI
- Qavat rejasini oching (yoki xonalarni tanlang) va "Pol" tugmasini bosing.
- Har xonaga pol turini tanlang yoki "Belgilanganlarning hammasiga" orqali bir yo'la qo'ying. Turlar - loyihadagi pol turlari.
- "Pol eshik va arka o'rinlariga kiradi" yoqilgan bo'lsa, pol eshik o'rnida devorning yarmigacha davom etadi.
- Pol turi xona nomi bo'yicha eslab qolinadi.
- "Almashtirish / O'tkazib yuborish" faqat shu asbob yaratgan pollarga taalluqli; qo'lda chizilgan pollarga tegilmaydi.
- Xonalar (Room) joylashtirilgan bo'lishi kerak. Egri devordagi eshiklar va Doors kategoriyasida bo'lmagan teshiklar hisobga olinmaydi.

LISTLAR TUGMASI ("Oformleniya" bo'limi)
- Chapda - listga qo'yish mumkin bo'lgan vidlar (reja, ship rejasi, qirqim, fasad, 3D, chizma vid, legenda).
  Allaqachon listda turgan vidlar ko'rsatilmaydi (legenda bundan mustasno - uni bir nechta listga qo'yish mumkin).
- Qidirish va tur bo'yicha filtr; "Ko'rinib turganlarni belgilash" faqat ro'yxatda ko'rinib turganlarni belgilaydi.
  Loyiha brauzerida oldindan tanlab qo'yilgan vidlar oyna ochilganda belgilangan bo'ladi.
- O'ngda: ramka (shtamp) turi yoki "ramkasiz", joylash usuli (har bir vid alohida listga / hammasi bitta listga),
  birinchi list raqami. Raqam loyihadagi oxirgi listdan davom ettirib taklif qilinadi; band raqamlar o'tkazib yuboriladi.
- "Har bir vid alohida listga": list nomi vid nomidan olinadi, vid list markaziga qo'yiladi.
  "Hammasi bitta listga": vidlar to'r bo'yicha qo'yiladi - joyini keyin qo'lda to'g'rilash kerak bo'lishi mumkin.
- Vid joylashmasa, bo'sh list qoldirilmaydi; sababi yakuniy xabarda yoziladi.
- Spetsifikatsiyalar (Schedule) hozircha ro'yxatda yo'q.

NOMERATOR TUGMASI ("Oformleniya" bo'limi)
- Ro'yxatda loyihadagi hamma listlar raqam tartibida turadi. Bir nechta listni Ctrl yoki Shift bilan tanlaysiz.
- Surish: "Tepaga / Pastga / Eng tepaga / Eng pastga". Raqam o'ringa tegishli: surilgan list o'sha o'rindagi
  raqamni oladi, qo'shnisi esa uning eski raqamini oladi.
- Raqam berish: birinchi raqamni yozing (masalan A-01) va "Qo'llash" - tanlangan listlar ro'yxat tartibida
  ketma-ket raqamlanadi (A-01, A-02, ...).
- O'zgargan qatorda "avval: ..." yoziladi. Takror raqam chiqsa, qator "takror" deb belgilanadi va saqlash
  to'g'rilanmaguncha yopiq turadi.
- Loyihaga faqat "Saqlash" bosilganda yoziladi. Revit biror listning raqamini o'zgartirishga ruxsat bermasa,
  hech bir list o'zgarmaydi va sababi ko'rsatiladi.
- "Qaytarish" oynadagi hamma o'zgarishni bekor qiladi (saqlanmagan bo'lsa).

SAQLASH TUGMASI ("Loyiha" bo'limi)
- Hali saqlanmagan loyihada: loyiha papkasini tanlaysiz, fayl nomini yozasiz. Papka ichida shular yaratiladi:
  010_Общие, 020_Исходные данные, 021_Библиотеки, 022_Шаблоны, 023_ТУ, 030_В работе, 040_Общий доступ,
  050_Опубликовано, 060_Архив - va Revit fayli "030_В работе" ichiga saqlanadi.
- Bor papkalarga tegilmaydi, faqat yo'qlari yaratiladi. Shu nomli fayl bo'lsa, ustidan yozishdan oldin so'raladi.
- Avval saqlangan faylda tugma oddiy saqlash qiladi (Ctrl+S kabi), papka yaratmaydi.
- Revit'ning o'z "Saqlash" tugmasi va Ctrl+S o'zgarmagan - papkalar faqat shu tugma orqali yaratiladi.
- Papkalar ro'yxati bitta joyda: lib\archstore\projfolders.py (FOLDERS va WORK).

SOZLAMALAR TUGMASI ("Sozlamalar" bo'limi)
- Hamma asboblarga taalluqli sozlamalar bitta joyda: mavzu (Revit kabi / Yorug' / Qorong'i), til (UZ / RU / EN)
  va yangilanish (o'rnatilgan versiya, "Yangilanishni tekshirish").
- Tanlov darhol saqlanadi. Ochiq turgan Katalog oynasi unga qaytilganda yangi mavzu va tilni oladi.
- Kam ishlatiladigan boshqa sozlamalar ham keyinchalik shu oynaga qo'shiladi.
